$(document).ready(function() {
	
	/**
	 * Custom Validator method 
	 */
	
	$.validator.addMethod("chars", function(value, element) {
		  return this.optional(element) || /^[a-z]+$/i.test(value);
		}, "Please Enter Only Characters [a-z, A-Z]");

	
	/**
	 * Validations
	 */
	$("#form").validate({
		rules : {
			firstName : {
				required : true,
				chars : true
			},
			lastName : {
				required : true,
				chars : true
			},
			dob : {
				required : true
			},
			gender : {
				required : true
			},
			phno : {
				required : true,
				digits : true,
				minlength: 10
				/*maxlength :12*/
			},
			state : {
				required : true
			},
			photo : {
				required : true
			}
		},

		messages : {
			firstName : {
				required : 'Please Enter Your FirstName'
			},
			lastName : {
				required : 'Please Enter Your LastName'
			},
			dob : {
				required : 'Select Your Date Of Birth'
			},
			gender : {
				required : 'Select Your Gender'
			},
			phno : {
				required : 'Enter Your Phone Number',
				digits : 'Please Enter Only Numbers[0-9]',
				minlength: 'Plese Enter 10 Digits Mobile Number'
			},
			state : {
				required : 'Select Your State'
			},
			photo : {
				required : 'Chooce your Photo'
			}
		},
		
		errorElement : 'div',

		/**
		 * To Set the Proper view of error msgs to radio button and checkboxs
		 */
		/*errorPlacement : function(error, element) {
			if (element.is(":radio")) {
				error.appendTo(element.parents(".gender"));
			}else{
				error.insertAfter(element);
			}
		}*/
		
	})
})