package com.usa.federal.gov.ssa.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.usa.federal.gov.ssa.config.SwaggerConfig;
import com.usa.federal.gov.ssa.model.SsnModel;
import com.usa.federal.gov.ssa.service.SsnService;
import com.usa.federal.gov.ssa.util.AppConstantsUtils;

/**
 * 
 * @author AHMED
 *
 *         This Controller is Used for SSN Enrollment
 */
@Controller
public class SsnEnrollmentController {
	/**
	 * This is used to Generate Log messages
	 */
	private static final Logger LOGGER = Logger.getLogger(SwaggerConfig.class);

	/**
	 * This Autowired is Used to fetch all the Service methods
	 */
	@Autowired
	private SsnService service;

	/**
	 * This method is used to display to form
	 * 
	 * @param model
	 * @return String
	 */
	@GetMapping("/")
	private String showEnrolmentForm(Model model) {

		LOGGER.debug("*** showEnrolmentForm method Started ***");
		model.addAttribute(AppConstantsUtils.SSN_MODEL, new SsnModel());

		/**
		 * Initialize Form Values
		 */
		formValues(model);

		LOGGER.debug("*** showEnrolmentForm method Started ***");
		LOGGER.info("*** showEnrolmentForm method Loaded Successfully ***");

		return AppConstantsUtils.SSN_ENROLLMENT;
	}

	/**
	 * This Method is used to process the form
	 * 
	 * @param user
	 * @param errors
	 * @param model
	 * @param attribute
	 * @return String
	 */
	@PostMapping("/submit")
	private String enrollmentProcessing(@Valid @ModelAttribute(AppConstantsUtils.SSN_MODEL)final SsnModel ssnModel,
			final BindingResult errors,final Model model, final RedirectAttributes attribute) {

		LOGGER.debug("*** enrollmentProcessing method Started ***");

		/**
		 * If Input Data is Not Valid
		 */
		if (errors.hasErrors()) {
			formValues(model);
			return AppConstantsUtils.SSN_ENROLLMENT;
		}

	
		// call service method
		final String result = service.insertEnrollment(ssnModel);

		attribute.addFlashAttribute(AppConstantsUtils.MSG, result);

		/**
		 * Initialize Form Values
		 */
		formValues(model);

		LOGGER.debug("*** enrollmentProcessing method Started ***");
		LOGGER.info("*** enrollmentProcessing method Executed Successfully ***");

		return AppConstantsUtils.REDIRECT_USER_REG;
		
	}

	/**
	 * This method is used to initialize the form values
	 * 
	 * @param model
	 */
	private void formValues(final Model model) {
		
		LOGGER.debug("*** formValues method Started ***");

		/**
		 * Variable Declarations
		 */
		List<String> genderList = null;
		List<String> statesModel = null;

		/**
		 * This list is used to initialize gender
		 */
		genderList = new ArrayList<>();
		genderList.add("");
		genderList.add(AppConstantsUtils.MALE);
		genderList.add(AppConstantsUtils.FEMALE);

		model.addAttribute(AppConstantsUtils.GENDER, genderList);

		/**
		 * Get all the State List and initialize it
		 */

		statesModel = service.statesList();

		// To set first element of the states list empty
		statesModel.set(0, "");

		LOGGER.info(statesModel);

		model.addAttribute(AppConstantsUtils.STATES, statesModel);

		LOGGER.debug("*** formValues method Started ***");
		LOGGER.debug("*** formValues method Executed Successfully ***");
	}

	/**
	 * This method is used to avoid double posting
	 * 
	 * @param model
	 * @return String
	 */
	@GetMapping("/userRegSuccess")
	private String handleDoublePost(final Model model) {

		LOGGER.debug("*** handleDoublePost method Started ***");

		/**
		 * Initialize Form Values
		 */
		formValues(model);

		model.addAttribute(AppConstantsUtils.SSN_MODEL, new SsnModel());

		LOGGER.debug("*** formValues method Ended ***");
		LOGGER.info("*** formValues method Executed Succesfully ***");

		return AppConstantsUtils.SSN_ENROLLMENT;
	}

	/**
	 * This method is used to display all the enrolled ssn's
	 * 
	 * @param model
	 * @return String
	 */
	@GetMapping("/viewSsnList")
	private String viewEnrolledSsns(final Model model) {

		LOGGER.debug("*** viewEnrolledSsns method Started ***");
		/**
		 * Variable Declaration
		 */
		List<SsnModel> ssnModelList = null;

		/**
		 * Call Service Method
		 */
		ssnModelList = service.retriveAllSsn();

		// set data to model attribute
		model.addAttribute(AppConstantsUtils.SSN_MODEL_LIST, ssnModelList);

		LOGGER.debug("*** viewEnrolledSsns method Ended ***");
		LOGGER.info("*** viewEnrolledSsns method Executed Successfully ***");

		return AppConstantsUtils.SSN_LIST_VIEW;
	}

}
