package com.usa.federal.gov.ssa.util;

/**
 * 
 * 
 * @author AHMED
 * 
 * 
 *         This constant class is used to declare all Constants
 *
 */
public class AppConstantsUtils {

	/**
	 * This Property is used for SSN_MODEL
	 */
	public static final String SSN_MODEL = "ssnModel";

	/**
	 * This Property is used for SSN_ENROLLMENT
	 */
	public static final String SSN_ENROLLMENT = "ssn_enrollment";

	/**
	 * This Property is used for MSG
	 */
	public static final String MSG = "msg";

	/**
	 * This Property are used for GENDER
	 */
	public static final String GENDER = "genders";

	/**
	 *  This property is used for MALE
	 */
	public static final String MALE = "Male";

	/**
	 * This Property is used FEMALE
	 */
	public static final String FEMALE = "Female";

	/**
	 * This Property is used for
	 */
	public static final String STATES = "states";

	/**
	 * This Property is used for REDIRECT_USER_REG_SUCCESS method
	 */
	public static final String REDIRECT_USER_REG = "redirect:/userRegSuccess";

	/**
	 * This Property is used for SSN_MODEL_LIST
	 */
	public static final String SSN_MODEL_LIST = "ssnModelList";

	/**
	 * This Property is used for SSN_LIST_VIEW
	 */
	public static final String SSN_LIST_VIEW = "ssn_list_view";
}
