package com.usa.federal.gov.ssa.exceptions;

/**
 * 
 * @author AHMED
 * 
 * 
 *         This is a Custom Exception Class to Handle Custom Exception
 *
 */
public class NoSsnFoundException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 12388996655421L;

	/**
	 * This Constructor is used to handle the exception
	 * 
	 * @param msg
	 */
	public NoSsnFoundException(String msg) {
		super(msg);
	}
}
