package com.usa.federal.gov.ssa.entity;


import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import lombok.Data;

/**
 * 
 * @author AHMED
 *
 * This Entity class is created for SsnEntity
 */

@Data
@Entity
@Table(name="SSN_MASTER")
public class SsnEntity {

	/**
	 * This filed is used for ssnNumber (Long - Type)
	 */
	@Id
	@SequenceGenerator(name="ssnGen", sequenceName="ssn_sequence", initialValue=988843261, allocationSize=1)
	@GeneratedValue(generator="ssnGen", strategy=GenerationType.SEQUENCE)
	private Long ssnNumber;
	
	/**
	 * This filed is used for firstName (String - Type)
	 */
	@Column(name="FIRST_NAME", length=15)
	private String firstName;

	/**
	 * This filed is used for lastName (String - Type)
	 */
	@Column(name="LAST_NAME", length=15)
	private String lastName;

	/**
	 * This filed is used for dob - Date Of Birth (String - Type)
	 */
	@Column(name="DOB")
	private String dob;

	/**
	 * This filed is used for gender (String - Type)
	 */
	@Column(name="GENDER", length=6)
	private String gender;
	
	/**
	 * This filed is used for phno - Phone Number (Long - Type)
	 */
	@Column(name="PHNO")
	private Long phno;

	/**
	 * This filed is used for state (String - Type)
	 */
	@Column(name="STATE", length=16)
	private String state;

	/**
	 * This filed is used for photo (byte[]/BLOB - Type)
	 */
	@Lob
	@Column(name="PHOTO")
	private byte[] photo;
	
	/**
	 * This filed is used for SSN Enrollment createDate  (TimeStamp - Type)
	 */
	@CreationTimestamp
	@Column(name="CREATE_DATE")
	private Timestamp createDate;
	
	/**
	 * This filed is used for SSN Enrollment updatedDate (TimeStamp - Type)
	 */
	@UpdateTimestamp
	@Column(name="UPDATE_DATE")
	private Date updatedDate;

	
}
