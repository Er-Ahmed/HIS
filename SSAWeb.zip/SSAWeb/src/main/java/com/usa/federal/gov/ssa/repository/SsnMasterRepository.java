package com.usa.federal.gov.ssa.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.usa.federal.gov.ssa.entity.SsnEntity;

/**
 * 
 * @author AHMED
 *
 *         This Repository is created for SSN_MASTER Table
 */

@Repository
public interface SsnMasterRepository extends JpaRepository<SsnEntity, Long> {


	/**
	 * This method is used to get STATE_NAME by passing SSN Number
	 * @param ssnNumber
	 * @return String
	 */
	@Query("select state from SsnEntity where ssnNumber=:ssnNumber")
	String findStateById(Long ssnNumber);

}
