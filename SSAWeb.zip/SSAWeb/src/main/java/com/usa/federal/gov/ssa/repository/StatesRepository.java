package com.usa.federal.gov.ssa.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.usa.federal.gov.ssa.entity.StatesEntity;

/**
 * 
 * @author AHMED
 *
 * This Repository is created for STATES_MASTER Table
 */

@Repository
public interface StatesRepository extends JpaRepository<StatesEntity, Integer>{
	
	/**
	 * This method is used to get LIST of STATE_NAMES from STATE_MASTER Table
	 * 
	 * @return List<String>
	 */
	@Query(value="select STATE_NAME from STATES_MASTER", nativeQuery=true)
	List<String> selectStates();

}
