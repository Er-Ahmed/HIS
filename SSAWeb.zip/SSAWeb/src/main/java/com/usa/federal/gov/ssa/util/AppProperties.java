package com.usa.federal.gov.ssa.util;

import java.util.HashMap;
import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * 
 * @author AHMED
 * 
 * This class is created to load all Propertied from yml file
 *
 */
@Configuration
@ConfigurationProperties(prefix="app")
public class AppProperties {
	
	/**
	 * Variable Declaration
	 */
	Map<String, String> properties=new HashMap<String, String>();

	
	/**
	 * Getters & Setters
	 * @return Map<String, String>
	 */
	public Map<String, String> getProperties() {
		return properties;
	}

	public void setProperties(Map<String, String> properties) {
		this.properties = properties;
	}
	
	

}
