package com.usa.federal.gov.ssa.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import org.hibernate.annotations.Cache;

import lombok.Data;

/**
 * 
 * @author AHMED
 *
 * This Entity class is created for StatesEntity
 */

@Data
@Entity(name="STATES_MASTER")

public class StatesEntity {

	/**
	 * This filed is used for stateId (Integer - Type)
	 */
	@Id
	private Integer stateId;
	
	/**
	 * This filed is used for stateCode (String - Type)
	 */
	@Column(name="STATE_CODE", length=3)
	private String stateCode;
	
	/**
	 * This filed is used for stateName (String - Type)
	 */
	@Column(name="STATE_NAME", length=10)
	private String stateName;
}
