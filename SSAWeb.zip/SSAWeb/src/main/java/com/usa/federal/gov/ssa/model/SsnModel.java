package com.usa.federal.gov.ssa.model;

import java.io.Serializable;
import java.util.Date;

import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

import lombok.Data;

/**
 * 
 * @author AHMED
 *
 *
 * This Model Class is created for SsnModel
 */

@Data
public class SsnModel {
	
	/**
	 * This filed is used for ssnNumber (Long - Type)
	 */
	private Long ssnNumber;

	/**
	 * This filed is used for firstName (String - Type)
	 */
	@NotEmpty(message = "First Name is Required")
	private String firstName;

	/**
	 * This filed is used for lastName (String - Type)
	 */
	@NotEmpty(message = "Last Name is Required")
	private String lastName;

	/**
	 * This filed is used for dob - Date Of Birth (String - Type)
	 */
	@NotEmpty(message = "Date Of Birth is Required")
	private String dob;

	/**
	 * This filed is used for gender (String - Type)
	 */
	@NotEmpty(message = "Gender is Required")
	private String gender;
	
	/**
	 * This filed is used for phno - Phone Number (Long - Type)
	 */
	@NotNull(message = "Phone Number is Required")
	private Long phno;

	/**
	 * This filed is used for state (String - Type)
	 */
	@NotEmpty(message = "State is Required")
	private String state;

	/**
	 * This filed is used for photo (byte[] - Type)
	 */
	@NotEmpty(message = "Photo is Required")
	private byte[] photo;
	
	/**
	 * This filed is used for SSN Enrollment createDate(Date - Type)
	 */
	private Date createDate;
	
	/**
	 * This filed is used for SSN Enrollment updatedDate (Date - Type)
	 */
	private Date updatedDate;
	
}
