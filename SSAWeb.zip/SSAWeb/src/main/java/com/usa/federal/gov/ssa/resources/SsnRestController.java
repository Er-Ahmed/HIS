package com.usa.federal.gov.ssa.resources;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.usa.federal.gov.ssa.config.SwaggerConfig;
import com.usa.federal.gov.ssa.exceptions.NoSsnFoundException;
import com.usa.federal.gov.ssa.service.SsnService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * This class is the RestController
 * 
 * @author AHMED
 *
 */

@RestController
@Api("This is SsnRestController")
public class SsnRestController {

	/**
	 * This Property is used to get Service method
	 */
	@Autowired
	private SsnService service;

	/**
	 * This is used to Generate Log messages
	 */
	private static final Logger LOGGER = Logger.getLogger(SwaggerConfig.class);

	/**
	 * This method is used to get the ssnNumber and return State Name
	 * 
	 * @param ssnNumber
	 * @return String
	 */
	@ApiOperation("This method gives you the State Name")
	@ApiResponses(value = { @ApiResponse(code = 400, message = "Invalid SsnNumber supplied"),
			@ApiResponse(code = 404, message = "SsnNumber not found") })
	
	//To Access through PostMan : --> http://localhost:9091/getStateBySsnNumber/88888
	@GetMapping("/getStateBySsnNumber/{ssnNumber}")
	private String getStateBySsnNumber(
			@ApiParam(value = "SsnNumber that you need to provide", required = true) @PathVariable("ssnNumber") String ssnNumber) {

		System.out.println(ssnNumber);
		LOGGER.debug("*** getStateBySsnNumber method Started ***");

		/**
		 * variable declaration
		 */
		String state = null;

		/**
		 * Call Service Method
		 */
		state = service.getStateById(Long.parseLong(ssnNumber));

		LOGGER.debug("*** getStateBySsnNumber method Ended ***");
		LOGGER.info("*** vgetStateBySsnNumber method Executed Successfully ***");

		return state;

	}
}
