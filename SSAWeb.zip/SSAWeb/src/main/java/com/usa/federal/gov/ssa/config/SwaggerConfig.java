package com.usa.federal.gov.ssa.config;

import org.apache.log4j.Logger;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;

/**
 * This class is used to configure Swagger Api
 * 
 * 
 * @author AHMED
 * 
 */
@Configuration
public class SwaggerConfig {
	
	/**
	 * This is used to Generate Log messages
	 */
	private static final Logger LOGGER= Logger.getLogger(SwaggerConfig.class);
	
	/**
	 * This Constructor is used to display a message when Swagger Started
	 */
	public SwaggerConfig() {
		LOGGER.debug("*** Swagger Configuration ***");
	}
	/**
	 * This method is used to return Docket Object for Swagger Api
	 * 
	 * @return Docket
	 */
	@Bean
	public Docket metaData() {
		
        return new Docket(DocumentationType.SWAGGER_2)

                .select().apis(RequestHandlerSelectors.basePackage("com.usa.federal.gov.ssa.resources"))
                .paths(PathSelectors.any())
                .build();
       
        
	}
}
