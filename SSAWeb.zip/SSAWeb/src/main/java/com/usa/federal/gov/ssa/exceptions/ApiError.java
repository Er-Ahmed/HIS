package com.usa.federal.gov.ssa.exceptions;

import java.util.Date;

import lombok.Data;

/**
 * 
 * @author AHMED
 * 
 * 
 * This Class is used to Display REST Error with Proper format
 *
 */

@Data
public class ApiError {

	/**
	 * This Field is used to display Error Code
	 */
	private Integer errCode;
	
	/**
	 * This Field is used to display Error Description
	 */
	private String errDesc;
	
	/**
	 * This Field is used to dispaly Error Date
	 */
	private Date date;

	/**
	 * This Constructor is used to set ApiError values
	 * @param errCode
	 * @param errDesc
	 * @param date
	 */
	public ApiError(Integer errCode, String errDesc, Date date) {
		super();
		this.errCode = errCode;
		this.errDesc = errDesc;
		this.date = date;
	}
	
	
}
