package com.usa.federal.gov.ssa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import springfox.documentation.swagger2.annotations.EnableSwagger2;


/**
 * 
 * @author AHMED
 *
 */
@SpringBootApplication
@EnableSwagger2
public class SpringMvcWithBootApplication {

	/**
	 * This is The Boot Main Method
	 * @param args
	 */
	public static void main(final String[] args) {
		SpringApplication.run(SpringMvcWithBootApplication.class, args);
	}

}
