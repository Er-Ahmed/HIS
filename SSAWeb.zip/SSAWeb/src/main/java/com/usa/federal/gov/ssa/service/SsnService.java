package com.usa.federal.gov.ssa.service;

import java.util.List;

import com.usa.federal.gov.ssa.model.SsnModel;

/**
 * 
 * @author AHMED
 *
 * This Service Interface is created for SsnService
 */

public interface SsnService {

	/**
	 * This abstract method is declare to get list of STATES from Repository
	 * @return List<String>
	 */
	List<String> statesList();
	
	/**
	 * This abstract method is declare to SAVE the DATA
	 * @param ssnModel
	 * @return String
	 */
	String insertEnrollment(SsnModel ssnModel);
	
	/**
	 * This abstract method is declare to get LIST of SSN_data
	 * @return List<SsnModel>
	 */
	List<SsnModel> retriveAllSsn();
	
	/**
	 * This abstract method is declare to get STATE by SSN NUMBER
	 * @param ssnNumber
	 * @return String
	 */
	String getStateById(Long ssnNumber);
}
