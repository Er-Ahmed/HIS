package com.usa.federal.gov.ssa.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.usa.federal.gov.ssa.entity.SsnEntity;
import com.usa.federal.gov.ssa.exceptions.NoSsnFoundException;
import com.usa.federal.gov.ssa.model.SsnModel;
import com.usa.federal.gov.ssa.repository.SsnMasterRepository;
import com.usa.federal.gov.ssa.repository.StatesRepository;

/**
 * 
 * 
 * @author AHMED
 *
 *         This Service class is created for SsnServiceImpl - Implementation
 *         class
 * 
 */

@Service
public class SsnServiceImpl implements SsnService {

	/**
	 * This is used to fetch states repo
	 */
	@Autowired
	private StatesRepository statesRepo;

	/**
	 * This is used to connect SsnRepo
	 */
	@Autowired
	private SsnMasterRepository ssnRepo;

	/**
	 * This method is used to fetch all states return List<String> stateList
	 * 
	 * @return List<String>
	 */
	@Override
	public List<String> statesList() {

		/**
		 * Variable Declaration
		 */
		List<String> statesEntity = null;

		statesEntity = statesRepo.selectStates();

		return statesEntity;
	}

	/**
	 * This method is used to save the ssnEnrollment return String
	 * 
	 * @param ssnModel
	 * @return String
	 * 
	 */
	@Override
	public String insertEnrollment(final SsnModel ssnModel) {

		/**
		 * Variable Declaration
		 */
		SsnEntity ssnEntity = new SsnEntity();
		String number = null;
		String ssnFormat = null;

		/**
		 * copy ssnModel to ssnEntity
		 */
		BeanUtils.copyProperties(ssnModel, ssnEntity);

		/**
		 * Save Data
		 */

		ssnEntity = ssnRepo.save(ssnEntity);

		// True if record successfully inserted
		if (ssnEntity.getSsnNumber() > 0) {

			// Logic to format the SSN NUMBER
			number = ssnEntity.getSsnNumber().toString();
			ssnFormat = number.substring(0, 3) + "-" + number.substring(3, 5) + "-" + number.substring(5, 9);
		}
		// "SSN Enrollment Completed Successfully with " +
		return ssnFormat;

	}

	/**
	 * This method is used to retrive all the list of Ssn_Enrolled Recoreds
	 * 
	 * @return List<SsnModel
	 */
	@Override
	public List<SsnModel> retriveAllSsn() {
		/**
		 * Variable Declaration
		 */
		List<SsnEntity> ssnEntity = null;
		final List<SsnModel> ssnModelList = new ArrayList<SsnModel>();

		// fetch all records
		ssnEntity = ssnRepo.findAll();

		// convert Entity List to Model List
		ssnEntity.forEach(entity -> {

			// create object for model
			final SsnModel model = new SsnModel();

			BeanUtils.copyProperties(entity, model);

			ssnModelList.add(model);
		});

		return ssnModelList;
	}

	/**
	 * This method return State name by taking ssnNumber from RestCall
	 * 
	 * @param Long ssnNumber
	 * @return String
	 */
	@Override
	public String getStateById(final Long ssnNumber) {
		/**
		 * Variable Declaration
		 */
		String state = null;

		// get state name
		state = ssnRepo.findStateById(ssnNumber);

		if (state != null) {
			return state;

		} else {
			throw new NoSsnFoundException("No SSN Enrolled with this SSN Nnumber ...!");
		}

	}
}
