package com.usa.federal.gov.ssa.model;

import lombok.Data;

/**
 * 
 * @author AHMED
 *
 * This Model class is created for StatesModel
 */

@Data
public class StatesModel {

	/**
	 * This filed is used for stateId (Integer - Type)
	 */
	private Integer stateId;
	
	/**
	 * This filed is used for stateCode (String - Type)
	 */
	private String stateCode;
	
	/**
	 * This filed is used for stateName (String - Type)
	 */
	private String stateName;
}
