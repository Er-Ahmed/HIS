package com.usa.federal.gov.ssa.exceptions;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;


/**
 * 
 * @author AHMED
 * 
 * 
 * This Class is used for Global Exceptional Handler
 *
 */
@Controller
@ControllerAdvice
public class AppExceptionHandler {

	/**
	 * This Method is used to handle All Exceptions 
	 * @param model
	 * @return String
	 */
	@ExceptionHandler(NullPointerException.class)
	public String handleException(final Model model) {
		
		model.addAttribute("errMsg", "Some Problem Occured, Plase Try Again After Sometimes...!");
		
		return "error";
	}
	
	
	
}
