$(document).ready(function() {
	/**
	 * 
	 * 
	 * Custom Validator method
	 * 
	 * 
	 */
	
	 /*********************** Validation to Accept only Alphabets ****************/
	 
	$.validator.addMethod("chars", function(value, element) {
		return this.optional(element) || /^[a-z]+$/i.test(value);
	}, "Please Enter Only Characters [a-z, A-Z]");
	
	
	
	
	/*********************** Validation to validate Email **************************/
	 
	$.validator.addMethod("emailValid", function(value, element) {
		return this.optional(element) || /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/.test(value);
		
	}, "Please Enter Valid Email ");

	
	/************************** Form Validations ******************************************* */
	$("#form").validate({

		rules : {
			firstName : {
				required : true,
				chars : true
			},
			lastName : {
				required : true,
				chars : true
			},
			dob : {
				required : true
			},
			gender : {
				required : true
			},
			email : {
				required : true,
				emailValid: true
				
			},
			password : {
				required : true
			},
			ssn : {
				required : true
				
			},

			mobileNumber : {
				required : true,
				digits : true,
				minlength : 10,
				maxlength :10 
			},
			userRole : {
				required : true
			},
		},

		messages : {
			firstName : {
				required : 'Please Enter FirstName'
			},
			lastName : {
				required : 'Please Enter LastName'
			},
			dob : {
				required : 'Please Select Date Of Birth'
			},
			gender : {
				required : 'Please Select Gender'
			},
			email : {
				required : 'Please Enter Email'
			},
			password : {
				required : 'Please Enter Password'
			},
			ssn : {
				required : 'Please Enter SSN Number',
				digits : 'Please Enter Only Numbers[0-9]'
				
					
			},
			mobileNumber : {
				required : 'Please Enter Mobile Number',
				digits : 'Please Enter Only Numbers[0-9]',
				minlength : 'Plese Enter 10 Digits Mobile Number'
			},
			userRole : {
				required : 'Please Select Role'
			},
		},

		errorElement : 'div',

	});
	

	/*********************** For Email Validation
	 * To Check Entered Email is UNIQUE or not *****************************/
	
	$("#emailId").blur(function() {

		var enteredEmail = $("#emailId").val();
		$.ajax({

			url : "validateEmail",
			data : "email=" + enteredEmail,
			success : function(result) {
				if (result == "Duplicate") {
					$("#emailMsg").html("Email is Already Registered...!");
					$("#emailId").focus();
					$("#submitbtn").prop("disabled", true);
				} else {
					$("#emailMsg").html("");
					$("#submitbtn").prop("disabled", false);
				}
			}

		});

	});
});




/********************* For DatePicker to show current date only*********************/
var today = new Date();
var dd = today.getDate();
var mm = today.getMonth() + 1; // January is 0!
var yyyy = today.getFullYear();
if (dd < 10) {
	dd = '0' + dd
}
if (mm < 10) {
	mm = '0' + mm
}

today = yyyy + '-' + mm + '-' + dd;
document.getElementById("datefield").setAttribute("max", today);



/*********************** SSN TextBoxes Script to get SSN By Masking ***************************/
function focus2() {
	
	var myLength = $('#ssn1').val().length;
	//console.log('Length : ' + myLength);
	if (myLength >= 3) {
		$('#ssn2').focus();
	}
}
function focus3() {
	var myLength = $('#ssn2').val().length;
	//console.log('Length : ' + myLength);
	if (myLength >= 2) {
		$('#ssn3').focus();
	}
}
function appentSSN() {
	var myLength = $('#ssn3').val().length;
	console.log('Length : ' + myLength);
	var data = $('#ssn1').val() + $('#ssn2').val() + $('#ssn3').val();
	console.log('Data : ' + data);
	$('#ssn_num').val(data);
	
}






