$(document).ready(function() {
	/**
	 * 
	 * 
	 * Custom Validator method
	 * 
	 * 
	 */
	
	 /*********************** Validation to Accept only Alphabets ****************/
	 
	$.validator.addMethod("chars", function(value, element) {
		return this.optional(element) || /^[a-z]+$/i.test(value);
	}, "Please Enter Only Characters [a-z, A-Z]");
	
	
	
	/*********************** Validation to validate Email **************************/
	 
	$.validator.addMethod("emailValid", function(value, element) {
		return this.optional(element) || /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/.test(value);
		
	}, "Please Enter Valid Email ");

	
	/************************** Form Validations ******************************************* */
	$("#form").validate({

		rules : {
			planName : {
				required : true,
				chars : true
			},
			planDescription : {
				required : true
				
			},
			startDate : {
				required : true,
			},
			endDate : {
				required : true
			},
			
		},

		messages : {
			planName : {
				required : 'Please Enter Plan Name'
			},
			planDescription : {
				required : 'Please Enter Plan Description'
			},
			startDate : {
				required : 'Please Select Plan Start Date', 
					
			},
			endDate : {
				required : 'Please Select Plan End Date'
			},
			
		},

		errorElement : 'div',

	});
	
});







