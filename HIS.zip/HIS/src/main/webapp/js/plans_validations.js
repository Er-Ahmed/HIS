$(document).ready(function() {
	/**
	 * 
	 * 
	 * Custom Validator method
	 * 
	 * 
	 */

	/** ********************* Validation to Accept only Alphabets *************** */

	$.validator.addMethod("chars", function(value, element) {
		return this.optional(element) || /^[a-z]+$/i.test(value);
	}, "Please Enter Only Characters [a-z, A-Z]");

	
	
	$(".allow_decimal").on("input", function(evt) {
		   var self = $(this);
		   self.val(self.val().replace(/[^0-9\.]/g, ''));
		   if ((evt.which != 46 || self.val().indexOf('.') != -1) && (evt.which < 48 || evt.which > 57)) 
		   {
		     evt.preventDefault();
		   }
		 });
	
	/** ************************ Form Validations ***************************** */
	$("#form").validate({

		rules : {

			kidsCount : {
				required : true,
				digits : true,
				min : 1
			},
			kidsAge : {
				required : true,
				digits : true,
				min : 1
			},
			parentsEmployed : {
				required : true,
			},
			familyIncome : {
				required : true,
				min : 1.0
			},

			isEmployed : {
				required : true,
			},

			employmentIncome : {
				required : true,
				min : 1
			},
			propertiesCost : {
				required : true,
				min : 1
			},
		},

		messages : {
			kidsCount : {
				required : 'Please Enter Kids Count',
				digits : 'Please Enter Only Numbers',
				min : 'Please Enter Number Of Kids'
			},
			kidsAge : {
				required : 'Please Enter Kids Age',
				digits : 'Please Enter Only Numbers',
				min : 'Please Enter Age of Kids'
			},
			parentsEmployed : {
				required : 'Please Select Parents Employed Y/N',
			},
			familyIncome : {
				required : 'Please Enter Family Income',
				min : 'Please Enter Family Income'
			},

			isEmployed : {
				required : 'Please Select Parents Employed Y/N',
			},

			employmentIncome : {
				required : 'Please Enter Employment Income',
				min : 'Please Enter Income'
			},

			propertiesCost : {
				required : 'Please Enter Properties Cost',
				min : 'Please Enter Properties Cost'
			},
		},

		errorElement : 'div',

	});

});
