$(document).ready(function() {
	/**
	 * 
	 * 
	 * Custom Validator method
	 * 
	 * 
	 */
	
	 /*********************** Validation to Accept only Alphabets ****************/
	 
	$.validator.addMethod("chars", function(value, element) {
		return this.optional(element) || /^[a-z]+$/i.test(value);
	}, "Please Enter Only Characters [a-z, A-Z]");
	
	
	
	
	/*********************** Validation to validate Email **************************/
	 
	$.validator.addMethod("emailValid", function(value, element) {
		return this.optional(element) || /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/.test(value);
		
	}, "Please Enter Valid Email ");

	
	/************************** Form Validations ******************************************* */
	$("#form").validate({

		rules : {
			userId : {
				required : true,
				emailValid : true
			},
			password : {
				required : true,
			}
		},

		messages : {
			userId : {
				required : 'Please Enter Your UserName',
				emailValid : 'Please Enter A Valid UserName'
			},
			password : {
				required : 'Please Enter Your Password'
			}
		},

		errorElement : 'div',

	});
	

	/*********************** For Email Validation
	 * To Check Entered Email is UNIQUE or not *****************************/
	
	$("#emailId").blur(function() {

		var enteredEmail = $("#emailId").val();
		$.ajax({

			url : "validateEmail",
			data : "email=" + enteredEmail,
			success : function(result) {
				if (result == "Duplicate") {
					$("#emailMsg").html("Email is Already Registered...!");
					$("#emailId").focus();
					$("#submitbtn").prop("disabled", true);
				} else {
					$("#emailMsg").html("");
					$("#submitbtn").prop("disabled", false);
				}
			}

		});

	});
});










