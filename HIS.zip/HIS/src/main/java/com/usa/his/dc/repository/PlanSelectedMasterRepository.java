package com.usa.his.dc.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.usa.his.dc.entity.PlanSelectedEntity;

/**
 * 
 * @author AHMED
 * 
 * This Interface is created for PLAN_SELECTED_MASTER Table Repository
 *
 */
@Repository
public interface PlanSelectedMasterRepository extends JpaRepository<PlanSelectedEntity, Integer> {

}
