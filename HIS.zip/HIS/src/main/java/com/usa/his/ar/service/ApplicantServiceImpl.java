package com.usa.his.ar.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.usa.his.ar.entity.ApplicantEntity;
import com.usa.his.ar.model.ApplicantModel;
import com.usa.his.ar.repository.ApplicantRegMasterRepository;

/**
 * 
 * @author AHMED
 * 
 *         This class is created for ApplicantServiceImpl - Implementation Class
 *
 */
@Service
public class ApplicantServiceImpl implements ApplicantService {

	/**
	 * This is used to Generate Log messages
	 */
	private static final Logger LOGGER = LogManager.getLogger(ApplicantServiceImpl.class);

	/**
	 * This Field is used to Inject ApplicantRegMasterRepository Object
	 */
	@Autowired
	private ApplicantRegMasterRepository appRegRepo;

	/**
	 * 
	 * This method is used for Applicant Registration
	 * 
	 * @param appModel
	 * @return String
	 * 
	 */
	@Override
	public Map<String, String> applicantRegistration(ApplicantModel appModel) throws Exception {

		LOGGER.debug("*** ApplicantServiceImpl :  applicantRegistration method Started ***");

		// Variable Declaration
		String stateName = null;
		ApplicantEntity appEntity = null;
		RestTemplate restTemp = null;
		Map<String, String> map = null;

		// create Object for Map
		map = new HashMap<String, String>();

		// create Object for RestTemplate
		restTemp = new RestTemplate();

		// Check given SSN belongs to WASHINGTON State or not
		stateName = restTemp.getForObject("http://localhost:9091/getStateBySsnNumber/" + appModel.getSsn(),
				String.class);

		// if State - Washington
		if (stateName.equals("Washington")) {

			// Create Object for Entity Class
			appEntity = new ApplicantEntity();

			// convert appModel to appEntity
			BeanUtils.copyProperties(appModel, appEntity);

			// save the record
			appEntity = appRegRepo.save(appEntity);

			// check for save
			if (!appEntity.getRegNumber().equals("")) {
				// if RegNumber is Generated
				map.put("SUCCESS", "Applicant Registration Success With Reg. No : " + appEntity.getRegNumber());

			} else {
				// if RegNumber is Not Generated
				map.put("FAIL", "Unable to Register... Please Try Again Later!");
			}
		} else {
			// if not State - Washington
			map.put("WRONG_STATE", "Applicant Belongs to " + stateName + " , Applicant Not Eligible");

		}

		LOGGER.debug("*** ApplicantServiceImpl :  applicantRegistration method Ended ***");
		LOGGER.info("*** ApplicantServiceImpl :  applicantRegistration method executed Successfully ***");

		// return Map
		return map;
	}

	/**
	 * 
	 * This Method is used to check to SSN If An Applicant trying apply more than
	 * one Plan
	 * 
	 * @param ssn
	 * @return String
	 * 
	 */
	@Override
	public String checkForSSN(Long ssn) {

		LOGGER.debug("*** ApplicantServiceImpl :  checkForSSN method Started ***");

		// Call findBySSN method
		Long ssnNo = appRegRepo.findBySSN(ssn);

		LOGGER.debug("*** ApplicantServiceImpl :  checkForSSN method Ended ***");
		LOGGER.info("*** ApplicantServiceImpl :  checkForSSN method executed Successfully ***");

		// Return String
		return (ssnNo == null) ? "Unique" : "Duplicate";
	}

	/**
	 * 
	 * This method is used to retrive All Registered Applicant List
	 * 
	 * @return List<ApplicantModel>
	 * 
	 */
	@Override
	public Page<ApplicantEntity> retriveAllApplicant(Integer pageNo, String orderName, String orderType) {

		LOGGER.debug("*** ApplicantServiceImpl :  retriveAllApplicant method Started ***");

		// Variable Declaration
		Page<ApplicantEntity> pageData = null;
		Pageable pageable = null;

		// NULL Check
		if (orderName != null && orderType != null) {

			// for Descending
			if (orderType.equals("Descending")) {
				pageable = PageRequest.of(pageNo, 3, Sort.by(orderName).descending());
			}

			// for Ascending
			else {
				pageable = PageRequest.of(pageNo, 3, Sort.by(orderName).ascending());
			}

			// First Hit to the Page without any sorting Request
		} else {
			pageable = PageRequest.of(pageNo, 3);
		}

		// get all records
		pageData = appRegRepo.findAll(pageable);

		LOGGER.debug("*** ApplicantServiceImpl :  retriveAllApplicant method Ended ***");
		LOGGER.info("*** ApplicantServiceImpl :  retriveAllApplicant method executed Successfully ***");

		// return List to controller
		return pageData;
	}

	/**
	 * This method is used to return Searching Data in List
	 * 
	 * @param searchBy
	 * @param searchTxt
	 * 
	 * @return List<ApplicantModel>
	 * 
	 */
	public List<ApplicantModel> searchingList(String searchBy, String searchTxt) {

		LOGGER.debug("*** ApplicantServiceImpl :  searchingList method Started ***");

		// Variable Declaration
		Optional<List<ApplicantEntity>> appEntityList = null;
		List<ApplicantModel> appModelList = new ArrayList<>();

		// Calling Repository Method
		appEntityList = appRegRepo.findByTxt(searchTxt);

		// NULL Check
		if (!appEntityList.isPresent()) {
			return null;
		}

		// Converting EntityList to ModelList
		for (ApplicantEntity appEntity : appEntityList.get()) {
			ApplicantModel appModel = new ApplicantModel();

			BeanUtils.copyProperties(appEntity, appModel);

			// Adding Model To ModelList
			appModelList.add(appModel);
		}

		LOGGER.debug("*** ApplicantServiceImpl :  searchingList method Ended ***");
		LOGGER.info("*** ApplicantServiceImpl :  searchingList method executed Successfully ***");

		// Return List
		return appModelList;
	}

	/**
	 * 
	 * This Method is used to Search the Single Object Data
	 * 
	 * @param searchBy
	 * @param searchTxt
	 * 
	 * @return ApplicantModel
	 * 
	 */
	@Override
	public ApplicantModel searching(String searchBy, String searchTxt) {

		LOGGER.debug("*** ApplicantServiceImpl :  searching method Started ***");

		// Variable Declaration
		Optional<ApplicantEntity> appEntity = null;
		ApplicantModel appModel = new ApplicantModel();

		// Condition for REG_NUMBER
		if (searchBy.equals("regNumber")) {
			appEntity = appRegRepo.findById(Integer.parseInt(searchTxt));
		}

		// Condition for SSN
		if (searchBy.equals("ssn")) {
			appEntity = appRegRepo.findBySsnNumber(Long.parseLong(searchTxt));
		}

		// Condition for EMAIL
		if (searchBy.equals("email")) {
			appEntity = appRegRepo.findByEmail(searchTxt);
		}

		// NULL Check
		if (appEntity.isPresent()) {

			// Converting appEntity to appModel
			BeanUtils.copyProperties(appEntity.get(), appModel);
		} else {

			// if NULL
			return null;
		}

		LOGGER.debug("*** ApplicantServiceImpl :  searching method Ended ***");
		LOGGER.info("*** ApplicantServiceImpl :  searching method executed Successfully ***");

		// Return appModel
		return appModel;
	}

}
