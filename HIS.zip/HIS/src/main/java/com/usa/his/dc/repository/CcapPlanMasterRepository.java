package com.usa.his.dc.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.usa.his.dc.entity.CcapPlanDataEntity;

public interface CcapPlanMasterRepository extends JpaRepository<CcapPlanDataEntity, Integer> {

}
