package com.usa.his.um.service;

import java.util.Map;

/**
 * 
 * @author AHMED
 * 
 * 
 * This interface is created for LoginServiceImpl
 *
 */
public interface LoginService {

	/**
	 * 
	 * This Method is used to Authenticate the User
	 * 
	 * @param userId
	 * @param password
	 * @return Map<String, String>
	 * @throws Exception
	 * 
	 */
	public Map<String, String> authenticateUser(String userId, String password) throws Exception;
	
	/**
	 * This Abstract Method is used to Send Password Recovery Mail
	 * 
	 * @param userId
	 * @return String
	 * @throws Exception
	 * 
	 */
	public String sendPasswordRecoveryMail(String userId) throws Exception;
}
