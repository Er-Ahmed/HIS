package com.usa.his.dc.entity;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import com.usa.his.ed.response.PlanInfo;


/**
 * 
 * @author AHMED
 * 
 * This is a Request class for MedicaidPlanData
 * 
 */


/**
 * <p>
 * Java class for anonymous complex type.
 * 
 * <p>
 * The following schema fragment specifies the expected content contained within
 * this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="employment-income" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *         &lt;element name="properties-cost" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *         &lt;element name="other-income" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = { "employmentIncome", "propertiesCost", "otherIncome", "planInfo" })
public class MedicaidPlanDataEntity {

	@XmlElement(name = "employment-income")
	protected double employmentIncome;
	
	@XmlElement(name = "properties-cost")
	protected double propertiesCost;
	
	@XmlElement(name = "other-income")
	protected double otherIncome;

	private PlanInfo planInfo;

	/**
	 * Get the value of the planInfo property
	 * 
	 * @return
	 */
	public PlanInfo getPlanInfo() {
		return planInfo;
	}

	public void setPlanInfo(PlanInfo planInfo) {
		this.planInfo = planInfo;
	}

	/**
	 * Gets the value of the employmentIncome property.
	 * 
	 */
	public double getEmploymentIncome() {
		return employmentIncome;
	}

	/**
	 * Sets the value of the employmentIncome property.
	 * 
	 */
	public void setEmploymentIncome(double value) {
		this.employmentIncome = value;
	}

	/**
	 * Gets the value of the propertiesCost property.
	 * 
	 */
	public double getPropertiesCost() {
		return propertiesCost;
	}

	/**
	 * Sets the value of the propertiesCost property.
	 * 
	 */
	public void setPropertiesCost(double value) {
		this.propertiesCost = value;
	}

	/**
	 * Gets the value of the otherIncome property.
	 * 
	 */
	public double getOtherIncome() {
		return otherIncome;
	}

	/**
	 * Sets the value of the otherIncome property.
	 * 
	 */
	public void setOtherIncome(double value) {
		this.otherIncome = value;
	}

	@Override
	public String toString() {
		return "MedicaidPlanData [employmentIncome=" + employmentIncome + ", propertiesCost=" + propertiesCost
				+ ", otherIncome=" + otherIncome + ", planInfo=" + planInfo + "]";
	}

	
}
