package com.usa.his.ed.rules.response;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import lombok.Data;

/**
 * 
 * @author AHMED
 * 
 * This is a Response class for PlanApproved
 * 
 */

/**
 * <p>
 * Java class for anonymous complex type.
 * 
 * <p>
 * The following schema fragment specifies the expected content contained within
 * this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="plan-start-date" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="plan-end-date" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="benefit-amt" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = { "planStartDate", "planEndDate", "benefitAmt" })
@Data
public class PlanApproved {

	@XmlElement(name = "plan-start-date", required = true)
	protected String planStartDate;
	
	@XmlElement(name = "plan-end-date", required = true)
	protected String planEndDate;
	
	@XmlElement(name = "benefit-amt")
	protected double benefitAmt;



}
