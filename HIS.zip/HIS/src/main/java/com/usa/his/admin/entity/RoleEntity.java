package com.usa.his.admin.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

/**
 * 
 * @author AHMED
 * 
 * 
 *         This class is used for RoleEntity
 *
 */

@Data
@Entity
@Table(name = "ROLE_MASTER")
public class RoleEntity {

	/**
	 * This Property is used for ROLE_ID
	 */
	@Id
	@Column(name = "ROLE_ID")
	private Integer roleId;

	/**
	 * This Property is used for USER_ROLE
	 */
	@Column(name = "USER_ROLE", length = 12)
	private String userRole;
}
