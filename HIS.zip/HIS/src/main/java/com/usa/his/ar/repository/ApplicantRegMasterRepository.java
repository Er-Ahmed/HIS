package com.usa.his.ar.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.usa.his.ar.entity.ApplicantEntity;

/**
 * 
 * @author AHMED
 * 
 * This interface is created for APPLICANT_REG_MASTER Table
 *
 */
@Repository
public interface ApplicantRegMasterRepository extends JpaRepository<ApplicantEntity, Integer>{

	//create Sequence app_reg_no_seq start with 1 increment by 1;
	
	/**
	 * This Abstract method is used to get sequence number form DB
	 * 
	 * @return Long
	 */
	@Query(value="SELECT APP_REG_NO_SEQ.NEXTVAL FROM DUAL", nativeQuery=true)
	public Long getSequenceNo();

	
	/**
	 * This method is used to get AccEnttiy using SSN for Plan Verification
	 * 
	 * @param ssn
	 * @return accEntity
	 * 
	 */
	@Query(value = "SELECT ssn FROM ApplicantEntity WHERE ssn=:ssn")
	public Long findBySSN(Long ssn);
	
	/**
	 * This method is used to get AccEnttiy using gender for Searching
	 *  
	 * @param ssn
	 * @return accEntity
	 * 
	 */
	@Query(value = "FROM ApplicantEntity WHERE gender=:searchTxt or firstName=:searchTxt or lastName=:searchTxt")
	public Optional<List<ApplicantEntity>> findByTxt(String searchTxt);
	
	/**
	 * This method is used to get AccEnttiy using SSN for Searching
	 *  
	 * @param ssn
	 * @return accEntity
	 * 
	 */
	@Query(value = "FROM ApplicantEntity WHERE ssn=:ssn")
	public Optional<ApplicantEntity> findBySsnNumber(Long ssn);
	
	/**
	 * This method is used to get AccEnttiy using gender for Searching
	 *  
	 * @param ssn
	 * @return accEntity
	 * 
	 */
	@Query(value = "FROM ApplicantEntity WHERE email=:email")
	public Optional<ApplicantEntity> findByEmail(String email);
	
	
}
