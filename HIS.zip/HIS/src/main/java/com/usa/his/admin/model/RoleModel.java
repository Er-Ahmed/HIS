package com.usa.his.admin.model;

import lombok.Data;

/**
 * 
 * @author AHMED
 * 
 * 
 *         This model class is used for RoleModel
 *
 */

@Data
public class RoleModel {

	/**
	 * This Property is used for ROLE_ID
	 */
	private Integer roleId;

	/**
	 * This Property is used for USER_ROLE
	 */
	private String userRole;
}
