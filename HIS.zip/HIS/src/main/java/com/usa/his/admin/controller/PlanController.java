package com.usa.his.admin.controller;

import javax.validation.Valid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.usa.his.admin.model.PlanModel;
import com.usa.his.admin.service.PlanService;
import com.usa.his.util.AppConstantsUtils;
import com.usa.his.util.AppProperties;

/**
 * 
 * @author AHMED
 * 
 *         This class is used as PlanController It will deal with all Requests &
 *         Responses
 *
 */

@Controller
public class PlanController {

	/**
	 * 
	 * This is used to Generate Log messages
	 * 
	 */
	private static final Logger LOGGER = LogManager.getLogger(PlanController.class);

	/**
	 * 
	 * This Field is used to Inject PlanServiceImpl Object
	 *
	 */
	@Autowired
	private PlanService planService;

	/**
	 * 
	 * This Field is used to Inject AppProperties Object
	 * 
	 */
	@Autowired
	private AppProperties props;

	/**
	 * This method is used to show Plan_Registration page
	 * 
	 * @param planModel
	 * @return String
	 * 
	 */
	@GetMapping("/planCreation")
	public String showPlanRegistrationForm(@ModelAttribute(AppConstantsUtils.PLAN_MODEL) final PlanModel planModel, final Model model) {
		LOGGER.debug("*** PlanController : showPlanRegistrationForm method Started ***");

		//To show Admin Link in NavBar
		model.addAttribute(AppConstantsUtils.ACCOUNT, AppConstantsUtils.ADMIN);
				
		LOGGER.debug("*** PlanController : showPlanRegistrationForm method Ended ***");
		LOGGER.info("*** PlanController : showPlanRegistrationForm method Loaded Successfully ***");

		/**
		 * Return View Name
		 */
		return AppConstantsUtils.PLAN_REGISTRATION_VIEW;
	}

	/**
	 * 
	 * This method is used to process the incoming model Data
	 * 
	 * @param planModel
	 * @param error
	 * @param attribute
	 * @return String
	 * 
	 */
	@PostMapping("planRegistration")
	public String processPlanRegistration(
			@Valid @ModelAttribute(AppConstantsUtils.PLAN_MODEL) final PlanModel planModel, final BindingResult error,
			final RedirectAttributes attribute, final Model model) {
		LOGGER.debug("*** PlanController : processPlanRegistration method Started ***");
		/**
		 * Variable Declaration
		 */
		Boolean result = null;

		/**
		 * Server Side Validation Check
		 */
		if (error.hasErrors()) {
			return AppConstantsUtils.PLAN_REGISTRATION_VIEW;
		}

		/**
		 * Call Service Method
		 */
		result = planService.savePlan(planModel);

		/**
		 * Add Message To Model Attribute
		 */
		if (result == true) {
			attribute.addFlashAttribute(AppConstantsUtils.SUCC_MSG,
					planModel.getPlanName() + props.getProperties().get(AppConstantsUtils.PLAN_CREATION_SUCC));
		} else {
			attribute.addFlashAttribute(AppConstantsUtils.FAIL_MSG,
					props.getProperties().get(AppConstantsUtils.PLAN_CREATION_FAIL) + planModel.getPlanName()
							+ " Plan");
		}
		
		//To show Admin Link in NavBar
		model.addAttribute(AppConstantsUtils.ACCOUNT, AppConstantsUtils.ADMIN);

		LOGGER.debug("*** PlanController : processPlanRegistration method Ended ***");
		LOGGER.info("*** PlanController : processPlanRegistration method Loaded Successfully ***");

		/**
		 * Return Redirect url to avoid double posting
		 */
		return AppConstantsUtils.REDIRECT_PLAN_REG;

	}

	/**
	 * 
	 * This method is used avoid Double Posting Problem
	 * 
	 * @param planModel
	 * @return String
	 * 
	 */
	@GetMapping("/planRegSuccess")
	public String planRegSucess(@ModelAttribute(AppConstantsUtils.PLAN_MODEL) final PlanModel planModel) {

		/**
		 * Return View name
		 */
		return AppConstantsUtils.PLAN_REGISTRATION_VIEW;
	}

	/**
	 * 
	 * This method is used to display AllPlanList on View
	 * 
	 * @param model
	 * @return String
	 * 
	 */
	@GetMapping("/getPlansList")
	public String getAllPlansList(final Model model) {
		LOGGER.debug("*** PlanController : getAllPlansList method Started ***");

		/**
		 * Call Service method set the list to model attribute
		 */
		model.addAttribute(AppConstantsUtils.PLAN_MODEL_LIST, planService.getAllPlans());

		//To show Admin Link in NavBar
		model.addAttribute(AppConstantsUtils.ACCOUNT, AppConstantsUtils.ADMIN);
				
		LOGGER.debug("*** PlanController : getAllPlansList method Ended ***");
		LOGGER.info("*** PlanController : getAllPlansList method Loaded Successfully ***");
		/**
		 * Return View Name
		 */
		return AppConstantsUtils.PLANS_LIST_VIEW;
	}

}
