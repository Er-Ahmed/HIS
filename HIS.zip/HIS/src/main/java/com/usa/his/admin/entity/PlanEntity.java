package com.usa.his.admin.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Data;

/**
 * 
 * @author AHMED
 * 
 * 
 *         This class is created for PlanEntity
 *
 */

@Data
@Entity
@Table(name = "PLAN_MASTER")
public class PlanEntity {

	/**
	 * This Property is used for PLAN_ID
	 */
	@Id
	@SequenceGenerator(name = "gen1", sequenceName = "plan_seq", initialValue = 1, allocationSize = 1)
	@GeneratedValue(generator = "gen1", strategy = GenerationType.SEQUENCE)
	private Integer planId;

	/**
	 * This Property is used for PLAN_NAME
	 */
	@Column(name = "PLAN_NAME", length = 10)
	private String planName;

	/**
	 * This Property is used for PLAN_DESCRIPTION
	 */
	@Column(name = "PLAN_DESCRIPTION")
	private String planDescription;

	/**
	 * This Property is used for START_DATE
	 */
	@Column(name = "START_DATE")
	private String startDate;

	/**
	 * This Property is used for END_DATE
	 */
	@Column(name = "END_DATE")
	private String endDate;

}
