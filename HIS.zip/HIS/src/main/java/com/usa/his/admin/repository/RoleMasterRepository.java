package com.usa.his.admin.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.usa.his.admin.entity.RoleEntity;

/**
 * 
 * @author AHMED
 * 
 * 
 * This interface Repository is created for ROLE_MASTER table
 *
 */
public interface RoleMasterRepository extends JpaRepository<RoleEntity, Integer>{
	
	@Query(value = "SELECT userRole FROM RoleEntity")
	public List<String> getAccRolesList();

}
