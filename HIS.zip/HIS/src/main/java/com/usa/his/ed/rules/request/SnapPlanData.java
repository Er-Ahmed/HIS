package com.usa.his.ed.rules.request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import com.usa.his.ed.rules.response.PlanInfo;

import lombok.Data;

/**
 * 
 * @author AHMED
 * 
 * This is a Request class for SnapPlanData
 * 
 */

/**
 * <p>
 * Java class for anonymous complex type.
 * 
 * <p>
 * The following schema fragment specifies the expected content contained within
 * this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="family-income" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *         &lt;element name="is-employed" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = { "familyIncome", "isEmployed", "planInfo" })
@Data
public class SnapPlanData {

	@XmlElement(name = "family-income")
	protected double familyIncome;
	@XmlElement(name = "is-employed", required = true)
	protected String isEmployed;

	private PlanInfo planInfo;

	

}