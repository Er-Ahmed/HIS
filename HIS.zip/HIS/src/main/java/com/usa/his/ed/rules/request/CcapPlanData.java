package com.usa.his.ed.rules.request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import com.usa.his.ed.rules.response.PlanInfo;

import lombok.Data;

/**
 * 
 * @author AHMED
 * 
 * This is a Request class for CcapPlanData
 */

/**
 * <p>
 * Java class for anonymous complex type.
 * 
 * <p>
 * The following schema fragment specifies the expected content contained within
 * this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="kids-count" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="kids-age" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="parents-employed" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="family-income" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = { "kidsCount", "kidsAge", "parentsEmployed", "familyIncome", "planInfo" })
@Data
public class CcapPlanData {

	@XmlElement(name = "kids-count")
	protected int kidsCount;
	
	@XmlElement(name = "kids-age")
	protected int kidsAge;
	
	@XmlElement(name = "parents-employed", required = true)
	protected String parentsEmployed;
	
	@XmlElement(name = "family-income")
	protected double familyIncome;

	private PlanInfo planInfo;

}