package com.usa.his.um.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.usa.his.um.service.LoginService;
import com.usa.his.util.AppConstantsUtils;

/**
 * 
 * @author AHMED
 * 
 *         This Controller is created to Handle All Login Related Reequest
 *
 */
@Controller
public class LoginController {

	/**
	 * This is a Global Variable 
	 */
	
	Map<String, String> returnMap=new HashMap<String, String>();
	/**
	 * This is used to Generate Log messages
	 */
	private static final Logger LOGGER = LogManager.getLogger(LoginController.class);

	/**
	 * This Filed is used to Inject LoginService Object
	 */
	@Autowired
	private LoginService loginService;

	/**
	 * 
	 * This Method is used to show LoginForm
	 * 
	 * @return String
	 * 
	 */
	@GetMapping("/")
	public String showLoginform() {
		return AppConstantsUtils.LOGIN_VIEW;
	}

	/**
	 * 
	 * This Method is used to check LoginCredentials
	 * 
	 * @param request
	 * @param model
	 * @return String
	 * 
	 */
	@PostMapping("/loginCredentials")
	public String loginCredentials(final HttpServletRequest request,final RedirectAttributes attributes, final Model model) {
		
		LOGGER.debug("*** AccountController : loginCredentials method Started ***");
		
		// Variable Declaration
		String userId = null;
		String password = null;
		Map<String, String> map = null;

		// Read Credentials from JSP
		userId = request.getParameter(AppConstantsUtils.USER_ID);
		password = request.getParameter(AppConstantsUtils.PASSWORD);

		// Server Side Validations
		if (userId == null || userId.equals("")) {
			attributes.addFlashAttribute(AppConstantsUtils.MSG, AppConstantsUtils.ENTER_CREDENTIALS);
			return AppConstantsUtils.LOGIN_VIEW;
		}
		if (password == null || password.equals("")) {
			attributes.addFlashAttribute(AppConstantsUtils.MSG, AppConstantsUtils.ENTER_CREDENTIALS);
			return AppConstantsUtils.LOGIN_VIEW;
		}

		try {
			// Calling Service method to Authenticate
			map = loginService.authenticateUser(userId, password);

		} catch (Exception e) {
			LOGGER.error("*** LoginController : loginCredentials method Got Error ***");
			e.printStackTrace();
		}

		// If given Credentials are of - ADMIN
		if (map.get(AppConstantsUtils.ACCOUNT).equals(AppConstantsUtils.ADMIN)) {
			returnMap.put(AppConstantsUtils.VIEW_NAME, AppConstantsUtils.ADMIN_DASHBOARD_VIEW);
			attributes.addFlashAttribute(AppConstantsUtils.ACCOUNT, AppConstantsUtils.ADMIN);
		}

		// If given Credentials are of - CASE-WORKER
		else if (map.get(AppConstantsUtils.ACCOUNT).equals(AppConstantsUtils.CASE_WORKER)) {
			attributes.addFlashAttribute(AppConstantsUtils.ACCOUNT, AppConstantsUtils.CASE_WORKER);
			returnMap.put(AppConstantsUtils.VIEW_NAME,AppConstantsUtils.CASE_WORKER_DASHBOARD_VIEW);
		}

		// If given Credentials account is - DEACTIVATED
		else if (map.get(AppConstantsUtils.ACCOUNT).equals(AppConstantsUtils.DE_ACTIVATED)) {
			attributes.addFlashAttribute(AppConstantsUtils.MSG, AppConstantsUtils.DE_ACTIVATED);
			returnMap.put(AppConstantsUtils.VIEW_NAME, AppConstantsUtils.LOGIN_VIEW);
		}

		// If given Credentials are - INVALID
		else {
			attributes.addFlashAttribute(AppConstantsUtils.MSG, AppConstantsUtils.INVALID_CREDENTIALS);
			returnMap.put(AppConstantsUtils.VIEW_NAME, AppConstantsUtils.LOGIN_VIEW);
		}
		
		LOGGER.debug("*** LoginController : loginCredentials method Ended ***");
		LOGGER.info("*** LoginController : loginCredentials method Loaded Successfully ***");
		
		return "redirect:/loginSuccess";

	}

	@GetMapping("/loginSuccess")
	public String loginSuccess(final Model model) {
		
		LOGGER.debug("*** AccountController : loginSuccess method Started ***");
		
		LOGGER.debug("*** LoginController : loginSuccess method Ended ***");
		LOGGER.info("*** LoginController : loginSuccess method Loaded Successfully ***");
		
		return returnMap.get(AppConstantsUtils.VIEW_NAME);
	}
	/**
	 * 
	 * This Method is used to show forgot Password Form
	 * 
	 * @return String
	 * 
	 */
	@GetMapping("/forgotPassword")
	public String showForgotPasswordForm() {
		return AppConstantsUtils.FORGOT_PASSWORD_VIEW;
	}

	/**
	 * 
	 * This Method is used to sent forgot Password Recovery Mail
	 * 
	 * @param userId
	 * @param model
	 * @return String
	 * 
	 */
	@PostMapping("forgotPassword")
	public String forgotPasswordRecovery(@RequestParam(AppConstantsUtils.USER_ID) String userId, final Model model) {
		
		LOGGER.debug("*** LoginController : forgotPasswordRecovery method Started ***");


		try {
			// Calling Service Method to Send Recovery Mail
			model.addAttribute(AppConstantsUtils.MSG, loginService.sendPasswordRecoveryMail(userId));
			
		} catch (Exception e) {
			
			LOGGER.error("*** LoginController : forgotPasswordRecovery method Got Error ***");
			e.printStackTrace();
		}

		LOGGER.debug("*** LoginController : forgotPasswordRecovery method Ended ***");
		LOGGER.info("*** LoginController : forgotPasswordRecovery method Loaded Successfully ***");

		return AppConstantsUtils.FORGOT_PASSWORD_VIEW;
	}
}
