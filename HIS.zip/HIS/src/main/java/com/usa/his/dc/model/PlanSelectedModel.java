package com.usa.his.dc.model;

import lombok.Data;

/**
 * 
 * @author AHMED
 * 
 * This class is created for PlanSelected Model
 *
 */

@Data
public class PlanSelectedModel {

	/**
	 * This Field is used for CASE_NUMBER
	 */
	private Integer caseNumber;
	
	/**
	 * This Field is used for PLAN_SELECTED
	 */
	private String planSelected;
}
