package com.usa.his.config;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.cache.CacheManager;
import org.springframework.cache.ehcache.EhCacheCacheManager;
import org.springframework.cache.ehcache.EhCacheManagerFactoryBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;

/**
 * 
 * This Configuration Class is used for Cache Configuration
 * 
 * @author AHMED
 *
 */

@Configuration
public class EhCacheConfig {

	/**
	 * This is used to Generate Log messages
	 */
	private static final Logger LOGGER = LogManager.getLogger(EhCacheConfig.class);

	/**
	 * This method is used to return Object for CacheManager for Caching Purpose
	 * 
	 * @return CacheManger
	 */
	@Bean
	public CacheManager cacheManager() {
		return new EhCacheCacheManager(ehCacheCacheManager().getObject());
	}

	/**
	 * This Method is used to Return EhCacheMangerFactoryBean
	 * 
	 * @return EhCacheMangerFactoryBean
	 */
	@Bean
	public EhCacheManagerFactoryBean ehCacheCacheManager() {

		LOGGER.debug("*** EhCacheConfig : cacheManager method Started ***");

		EhCacheManagerFactoryBean cmfb = new EhCacheManagerFactoryBean();
		cmfb.setConfigLocation(new ClassPathResource("ehcache.xml"));
		cmfb.setShared(true);

		LOGGER.debug("*** EhCacheConfig : cacheManager method Ended ***");
		LOGGER.info("*** EhCacheConfig : cacheManager method executed Successfully ***");
		return cmfb;
	}
}
