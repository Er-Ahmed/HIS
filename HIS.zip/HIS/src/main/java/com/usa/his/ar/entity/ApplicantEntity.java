package com.usa.his.ar.entity;


import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.UpdateTimestamp;

import lombok.Data;

/**
 * 
 * @author AHMED
 * 
 * This class is created for Applicant Entity
 *
 */
@Data
@Entity
@Table(name="APPLICANT_REG_MASTER")
public class ApplicantEntity {

	/**
	 * This Filed is used for REG_NUMBER
	 */
	@Id
	@SequenceGenerator(name = "reg_no", sequenceName="APP_REG_NO_SEQ", allocationSize=1, initialValue=1)
    @GeneratedValue(generator = "reg_no")  
	private Integer regNumber;

	/**
	 * This Filed is used for FIRST_NAME
	 */
	@Column(name="FIRST_NAME", length=15)
	private String firstName;

	/**
	 * This Filed is used for LAST_NAME
	 */
	@Column(name="LAST_NAME", length=15)
	private String lastName;

	/**
	 * This Filed is used for GENDER
	 */
	@Column(name="GENDER", length=10)
	private String gender;
	
	/**
	 * This Field is used for DOB
	 */
	@Column(name="dob")
	private String dob;

	/**
	 * This Filed is used for EMAIL
	 */
	@Column(name="EMAIL", length=25)
	private String email;

	/**
	 * This Filed is used for SSN
	 */
	@Column(name="SSN", length=9)
	private Long ssn;
	
	/**
	 * This Filed is used for MOBILE_NUMBER
	 */
	@Column(name="MOBILE_NUM", length=15)
	private Long mobileNumber;

	/**
	 * This Filed is used for CREATION_DATE
	 */
	@CreationTimestamp
	@Column(name="CREATION_DATE")
	private Date creationDate;

	/**
	 * This Filed is used for UPDATION_DATE
	 */
	@UpdateTimestamp
	@Column(name="UPDATEION_DATE")
	private Date updationDate;

}
