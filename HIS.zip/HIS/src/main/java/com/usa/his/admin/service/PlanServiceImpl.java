package com.usa.his.admin.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.usa.his.admin.entity.PlanEntity;
import com.usa.his.admin.model.PlanModel;
import com.usa.his.admin.repository.PlanMasterRepository;

/**
 * 
 * @author AHMED
 * 
 *         This class is created for PlanServiceImpl - Implementation Class
 *
 */

@Service
public class PlanServiceImpl implements PlanService {
	/**
	 * 
	 * This is used to Generate Log messages
	 * 
	 */
	private static final Logger LOGGER = LogManager.getLogger(PlanServiceImpl.class);
	
	/**
	 * This Field is used to Inject PlanRepository Object
	 */
	@Autowired
	private PlanMasterRepository planRepo;

	/**
	 * 
	 * This method is used to Save the Plan
	 * 
	 */
	@Override
	public Boolean savePlan(PlanModel planModel) {
		LOGGER.debug("*** PlanServiceImpl : savePlan method Started ***");
		/**
		 * Variable Declaration
		 */
		PlanEntity planEntity = null;

		/**
		 * create Object for PlanEntity
		 */
		planEntity = new PlanEntity();

		/**
		 * Copy PlanModel Properties to PlanEntity
		 */
		BeanUtils.copyProperties(planModel, planEntity);
		System.out.println(planEntity);
		/**
		 * Save the Record
		 */
		planEntity = planRepo.save(planEntity);
		
		LOGGER.debug("*** PlanServiceImpl :  savePlan method Ended ***");
		LOGGER.info("*** PlanServiceImpl :  savePlan method executed Successfully ***");

		/**
		 * Return Boolean Value TRUE or FALSE
		 */
		return (planEntity.getPlanId() > 0) ? true : false;
	}

	/**
	 *
	 * This method is used to return all the Plans List
	 * 
	 */

	@Override
	public List<PlanModel> getAllPlans() {
		LOGGER.debug("*** PlanServiceImpl : getAllPlans method Started ***");
		/**
		 * Variable Declaration
		 */
		List<PlanEntity> planEntityList = null;

		/**
		 * Get All Plans
		 */
		planEntityList = planRepo.findAll();

		/**
		 * Create Object for planModelList
		 */
		List<PlanModel> planModelList = new ArrayList<PlanModel>(planEntityList.size());

		/**
		 * Convert planEntityList to planModelList
		 */
		planEntityList.forEach(planEntity -> {
			PlanModel planModel = new PlanModel();
			BeanUtils.copyProperties(planEntity, planModel);
			planModelList.add(planModel);
		});

		LOGGER.debug("*** PlanServiceImpl :  getAllPlans method Ended ***");
		LOGGER.info("*** PlanServiceImpl :  getAllPlans method executed Successfully ***");
		
		/**
		 * 
		 * Return planModel List to Controller
		 */
		return planModelList;
	}

}
