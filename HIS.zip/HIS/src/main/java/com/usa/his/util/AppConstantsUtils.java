package com.usa.his.util;

/**
 * 
 * @author AHMED
 * 
 * 
 *         This class is used to declared all Constants
 *
 */
public class AppConstantsUtils {

	/**
	 * 
	 * Admin Module
	 * 
	 * 
	 */
	/**
	 * This Property is used for REG_FORM_VIEW
	 */
	public static final String REG_FORM_VIEW = "acc_registration";

	/**
	 * This Property is used for ACC_MODEL
	 */
	public static final String ACC_MODEL = "accModel";

	/**
	 * This Property is used for REDIRECT_ACC_REG_SUCCESS
	 */
	public static final String REDIRECT_ACC_REG = "redirect:/accRegSuccess";

	/**
	 * This Property is used for ACC_LIST_VIEW
	 */
	public static final String ACC_LIST_VIEW = "acc_list_view";

	/**
	 * This Property is used for ACC_MODEL_LIST
	 */
	public static final String ACC_MODEL_LIST = "accModelList";

	/**
	 * This Property is used for SUCC_MSG
	 */
	public static final String SUCC_MSG = "succMsg";

	/**
	 * This Property is used for ACC_REG_SUCC
	 */
	public static final String ACC_REG_SUCC = "accRegSucc";

	/**
	 * This Property is used for PLAN_CREATION_SUCC
	 */
	public static final String PLAN_CREATION_SUCC = "planCreationSucc";

	/**
	 * This Property is used for FAIL_MSG
	 */
	public static final String FAIL_MSG = "failMsg";

	/**
	 * This Property is used for ACC_REG_FAIL
	 */
	public static final String ACC_REG_FAIL = "accRegFail";

	/**
	 * This Property is used for PLAN_CREATION_FAIL
	 */
	public static final String PLAN_CREATION_FAIL = "planCreationFail";

	/**
	 * This Property is used for MALE
	 */
	public static final String MALE = "Male";

	/**
	 * This Property is used for FE-MALE
	 */
	public static final String FE_MALE = "Fe-Male";

	/**
	 * This Property is used for GENDERS
	 */
	public static final String GENDERS = "genders";

	/**
	 * This Property is used for ROLES
	 */
	public static final String ROLES = "roles";

	/**
	 * This Property is used for PLAN_MODEL
	 */
	public static final String PLAN_MODEL = "planModel";

	/**
	 * This Property is used for PLAN_REGISTRATION_VIEW
	 */
	public static final String PLAN_REGISTRATION_VIEW = "plan_registration";

	/**
	 * This Property is used for REDIRECT_PLAN_REG_SUCCESS
	 */
	public static final String REDIRECT_PLAN_REG = "redirect:/planRegSuccess";

	/**
	 * This Property is used for PLAN_MODEL_LIST
	 */
	public static final String PLAN_MODEL_LIST = "planModelList";

	/**
	 * This Property is used for PLANS_LIST_VIEW
	 */
	public static final String PLANS_LIST_VIEW = "plans_list_view";

	/**
	 * This Property is used for ID
	 */
	public static final String ID = "id";

	/**
	 * This Property is used for ACC_MSG
	 */
	public static final String ACC_MSG = "accMsg";

	/**
	 * This Property is used for HIS_ADMIN_PHNO
	 */
	public static final String HIS_ADMIN_PHNO = "9876543210";

	/**
	 * This Property is used for HIS_URL
	 */
	public static final String HIS_URL = "<a href='http://localhost:9093/login'>HIS</a>";

	/**
	 * This Property is used for ACC_CREATION_EMAIL_BODY_TEMP
	 */
	public static final String ACC_CREATION_EMAIL_BODY_TEMP = "acc_creation_email_body_temp";

	/**
	 * This Property is used for PASS_RECOVERY_EMAIL_BODY_TEMP
	 */
	public static final String PASS_RECOVERY_EMAIL_BODY_TEMP = "pass_recovery_email_body_temp";

	/**
	 * This Property is used for LOGIN_VIEW
	 */
	public static final String LOGIN_VIEW = "login";

	/**
	 * This Property is used for USER_ID
	 */
	public static final String USER_ID = "userId";

	/**
	 * This Property is used for PASSWORD
	 */
	public static final String PASSWORD = "password";

	/**
	 * This Property is used for MSG
	 */
	public static final String MSG = "msg";

	/**
	 * This Property is used for ENTER_CREDENTIALS
	 */
	public static final String ENTER_CREDENTIALS = "enterCredentials";

	/**
	 * This Property is used for ACCOUNT
	 */
	public static final String ACCOUNT = "account";

	/**
	 * This Property is used for ADMIN
	 */
	public static final String ADMIN = "Admin";

	/**
	 * This Property is used for VIEW_NAME
	 */
	public static final String VIEW_NAME = "viewName";

	/**
	 * This Property is used for CASE_WORKER
	 */
	public static final String CASE_WORKER = "Case_Worker";

	/**
	 * This Property is used for ADMIN_DASHBOARD_VIEW
	 */
	public static final String ADMIN_DASHBOARD_VIEW = "admin_dashboard";

	/**
	 * This Property is used for CASE_WORKER_DASHBOARD_VIEW
	 */
	public static final String CASE_WORKER_DASHBOARD_VIEW = "case_worker_dashboard";

	/**
	 * This Property is used for DE_ACTIVATED
	 */
	public static final String DE_ACTIVATED = "deActivated";

	/**
	 * This Property is used for INVALID_CREDENTIALS
	 */
	public static final String INVALID_CREDENTIALS = "invalidCredentials";

	/**
	 * This Property is used for FORGOT_PASSWORD_VIEW
	 */
	public static final String FORGOT_PASSWORD_VIEW = "forgot_password";

	/**
	 * This Property is used for INVALID
	 */
	public static final String INVALID = "INVALID";

	/**
	 * This Property is used for ACC_SW_Y
	 */
	public static final String ACC_SW_Y = "Y";

	/**
	 * This Property is used for RECOVERY_PASS_SENT_MSG
	 */
	public static final String RECOVERY_PASS_SENT_MSG = "recoveryPassSendMsg";

	/**
	 * This Property is used for INVALID_USER_ID_MSG
	 */
	public static final String INVALID_USER_ID_MSG = "invalidUserId";

	
	/**
	 * 
	 * Application Registration Module
	 * 
	 */
	/**
	 * This Property is used for DUPLICATE_SSN_HOLDER
	 */
	public static final String DUPLICATE_SSN_HOLDER = "duplicateSsnHolder";

	/**
	 * This Property is used for APP_MODEL
	 */
	public static final String APP_MODEL = "appModel";

	/**
	 * This Property is used for APPLICANT_REG_VIEW
	 */
	public static final String APPLICANT_REG_VIEW = "applicant_registration";

	/**
	 * This Property is used for DUPLICATE
	 */
	public static final String DUPLICATE = "Duplicate";

	/**
	 * This Property is used for SUCCESS
	 */
	public static final String SUCCESS = "SUCCESS";

	/**
	 * This Property is used for FAIL
	 */
	public static final String FAIL = "FAIL";

	/**
	 * This Property is used for WRONG_STATE
	 */
	public static final String WRONG_STATE = "WRONG_STATE";
	
	/**
	 * This Property is used for REDIRECT_APP_REG_SUCC
	 */
	public static final String REDIRET_APP_REG_SUSS="redirect:/appRegSuccess";
	
	/**
	 * This Property is used for APP_MODEL_LIST
	 */
	public static final String APP_MODEL_LIST = "appModelList";
	
	/**
	 * This Property is used for APP_LIST_VIEW
	 */
	public static final String APP_LIST_VIEW = "applicant_list_view";
	
	/**
	 * This Property is used for REDIRECT_APP_LIST_VIEW
	 */
	public static final String REDIRECT_APP_LIST_VIEW ="redirect:/viewAppList";
	
	/**
	 * This Property is used for SEARCH_NOT_FOUND
	 */
	public static final String SEARCH_NOT_FOUND = "searchNotFound";
	
	/**
	 * This Property is used for PG_NO
	 */
	public static final String PG_NO = "pgNo";
	
	/**
	 * This Property is used for ORDER_NAME
	 */
	public static final String ORDER_NAME = "orderName";
	
	/**
	 * This Property is used for ORDER_TYPE
	 */
	public static final String ORDER_TYPE = "orderType";
	
	/**
	 * This Property is used for SEARCH_BY
	 */
	public static final String SEARCH_BY = "searchBy";
	
	/**
	 * This Property is used for TEXT
	 */
	public static final String TEXT = "text";
	
	/**
	 * This Property is used for REG_NUMBER
	 */
	public static final String REG_NUMBER = "regNumber";
	
	/**
	 * This Property is used for EMAIL
	 */
	public static final String EMAIL = "email";
	
	/**
	 * This Property is used for SSN
	 */
	public static final String SSN = "ssn";
	

}
