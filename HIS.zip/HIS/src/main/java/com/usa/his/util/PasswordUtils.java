package com.usa.his.util;

import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.usa.his.admin.service.AccServiceImpl;

/**
 * 
 * @author AHMED
 * 
 * This utility class is used for Password Encryption And Decryption
 * 
 *
 */
public class PasswordUtils {
	
	/**
	 * 
	 * This is used to Generate Log messages
	 * 
	 */
	private static final Logger LOGGER = LogManager.getLogger(PasswordUtils.class);

	/**
	 * Static final Values
	 */
	private static final String INIT_VECTOR = "encryptionIntVec";
	private static final String KEY = "aesEncryptionKey";

	/**
	 * This method is used to Encrypt + Encode The Password
	 * 
	 * @param plainPass
	 * @return String
	 * @throws Exception
	 */
	public static String encryptPassword(String plainPass) throws Exception {

		LOGGER.debug("*** PasswordUtils :  encryptPassword method Started ***");
		
		IvParameterSpec ips = new IvParameterSpec(INIT_VECTOR.getBytes("UTF-8"));
		SecretKeySpec sks = new SecretKeySpec(KEY.getBytes("UTF-8"), "AES");

		Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
		cipher.init(Cipher.ENCRYPT_MODE, sks, ips);

		byte[] encrypted = cipher.doFinal(plainPass.getBytes());
		
		LOGGER.debug("*** PasswordUtils :  encryptPassword method Ended ***");
		LOGGER.info("*** PasswordUtils :  encryptPassword method executed Successfully ***");
		
		return  Base64.getEncoder().encodeToString(encrypted);
	}

	/**
	 * This method is used to Decrypt + Decode the Password
	 * 
	 * @param encryptedPass
	 * @return String
	 * @throws Exception
	 */
	public static String decryptePassword(String encryptedPass) throws Exception {
		
		LOGGER.debug("*** PasswordUtils :  decryptePassword method Started ***");

		IvParameterSpec ips = new IvParameterSpec(INIT_VECTOR.getBytes("UTF-8"));
		SecretKeySpec sks = new SecretKeySpec(KEY.getBytes("UTF-8"), "AES");

		Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
		cipher.init(Cipher.DECRYPT_MODE, sks, ips);

		byte[] decrypted = cipher.doFinal(Base64.getDecoder().decode(encryptedPass));
		
		LOGGER.debug("*** PasswordUtils :  decryptePassword method Ended ***");
		LOGGER.info("*** PasswordUtils :  decryptePassword method executed Successfully ***");
		
		return new String(decrypted);
	}
	
	
}
