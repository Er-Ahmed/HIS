package com.usa.his.admin.repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.usa.his.admin.entity.AccEntity;

/**
 * 
 * @author AHMED
 * 
 * 
 *         This interface Repository is created for ACCOUNT_MASTER table
 *
 */

@Repository
public interface AccountMasterRepository extends JpaRepository<AccEntity, Integer> {

	/**
	 * This method is used to get email id from table
	 * 
	 * @param email
	 * @return String
	 */
	@Query(value = "SELECT email FROM AccEntity WHERE email=:email")
	public String findByEmail(String email);

	/**
	 * This method is used De-Active the Account By Soft Deleting Setting trgSW to
	 * 'N'
	 * 
	 * @param id
	 */
	@Modifying
	@Transactional
	@Query(value = "UPDATE AccEntity SET ACTIVE_SW='N' WHERE id=:id")
	public Integer deActivateUserById(Integer id);

	/**
	 * This method is used De-Active the Account By Soft Deleting Setting trgSW to
	 * 'N'
	 * 
	 * @param id
	 */
	@Modifying
	@Transactional
	@Query(value = "UPDATE AccEntity SET ACTIVE_SW='Y' WHERE id=:id")
	public Integer activateUserById(Integer id);

	/**
	 * This method is used to get AccEnttiy using Email for Login Authentication
	 * 
	 * @param userName
	 * @return accEntity
	 * 
	 */
	@Query(value = "FROM AccEntity WHERE email=:userId")
	public AccEntity getAccountByEmail(String userId);

}
