package com.usa.his.admin.model;

import java.util.Date;

import javax.validation.constraints.NotEmpty;

import lombok.Data;

/**
 * 
 * @author AHMED
 * 
 * 
 *         This class is created for Plan Model
 *
 */
@Data
public class PlanModel {

	/**
	 * This Property is used for PLAN_ID
	 */
	private Integer planId;

	/**
	 * This Property is used for PLAN_NAME
	 */
	@NotEmpty(message = "Enter Plan Name")
	private String planName;

	/**
	 * This Property is used for PLAN_DESCRIPTION
	 */
	@NotEmpty(message = "Enter Plan Description")
	private String planDescription;

	/**
	 * This Property is used for START_DATE
	 */
	@NotEmpty(message = "Enter Plan Start Date")
	private String startDate;

	/**
	 * This Property is used for END_DATE
	 */
	@NotEmpty(message = "Enter Plan End Date")
	private String endDate;

}
