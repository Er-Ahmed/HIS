package com.usa.his.admin.model;

import java.util.Date;

import javax.persistence.Column;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import lombok.Data;

/**
 * 
 * @author AHMED
 * 
 * 
 *         This Class is created for User Model
 *
 */
@Data
public class AccModel {

	/**
	 * This Property is used for ID
	 */
	private Integer id;

	/**
	 * This Property is used for FIRST_NAME
	 */
	@NotEmpty(message = "First Name is Required")
	private String firstName;

	/**
	 * This Property is used for LAST_NAME
	 */
	@NotEmpty(message = "Last Name is Required")
	private String lastName;

	/**
	 * This Property is used for GENDER
	 */
	@NotEmpty(message = "Gender is Required")
	private String gender;

	/**
	 * This Property is used for EMAIL
	 */
	@NotEmpty(message = "Email is Required")
	private String email;

	/**
	 * This Property is used for PASSWORD
	 */
	@NotEmpty(message = "Password is Required")
	private String password;

	/**
	 * This Property is used for DOB
	 */
	@NotEmpty(message = "Date Of Birth is Required")
	private String dob;

	/**
	 * This Property is used for SSN
	 */
	@NotNull(message = "SSN Number is Required")
	private Long ssn;

	/**
	 * This Property is used for MOBILE_NUMBER
	 */
	@NotNull(message = "Mobile Number is Required")
	private Long mobileNumber;

	/**
	 * This Property is used for USER_ROLE
	 */
	@NotEmpty(message = "Role is Required")
	private String userRole;

	/**
	 * This Property is used for TRG_SW (Y|N)
	 */
	private String activeSW;

	/**
	 * This Property is used for CREATION_DATE
	 */
	private Date creationDate;

	/**
	 * This Property is used for UPDATED_DATE
	 */
	private Date updatedDate;
}
