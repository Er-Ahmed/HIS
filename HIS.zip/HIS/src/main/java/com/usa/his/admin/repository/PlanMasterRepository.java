package com.usa.his.admin.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.usa.his.admin.entity.PlanEntity;

/**
 * 
 * @author AHMED
 * 
 * 
 *         This interface is created for PlanMasterRepository
 *
 */
@Repository
public interface PlanMasterRepository extends JpaRepository<PlanEntity, Integer> {

}
