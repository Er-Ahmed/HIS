package com.usa.his.dc.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.BeanFactoryAnnotationUtils;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.usa.his.ar.entity.ApplicantEntity;
import com.usa.his.ar.model.ApplicantModel;
import com.usa.his.ar.repository.ApplicantRegMasterRepository;
import com.usa.his.dc.entity.CaseEntity;
import com.usa.his.dc.entity.CcapPlanDataEntity;
import com.usa.his.dc.entity.PlanSelectedEntity;
import com.usa.his.dc.model.CaseModel;
import com.usa.his.dc.model.CcapPlanDataModel;
import com.usa.his.dc.model.PlanSelectedModel;
import com.usa.his.dc.repository.CaseMasterRepository;
import com.usa.his.dc.repository.CcapPlanMasterRepository;
import com.usa.his.dc.repository.PlanSelectedMasterRepository;
import com.usa.his.ed.response.PlanInfo;
import com.usa.his.ed.rules.request.CcapPlanData;
import com.usa.his.ed.rules.request.EligibilityDetermination;
import com.usa.his.ed.rules.request.EligibilityDetermination.CitigenData;
import com.usa.his.ed.rules.request.EligibilityDetermination.PlanDetails;

/**
 * 
 * @author AHMED
 * 
 *         This Class is created for DataCollectionServiceImpl - Implementation
 *         Class
 *
 */
@Service
public class DataCollectionServiceImpl implements DataCollectionService {

	/**
	 * This Field is used to Inject AR Module's Repository Object
	 */
	@Autowired
	private ApplicantRegMasterRepository appRegRepo;

	/**
	 * This Field is used to Inject CreateCaseMasterRepository Object
	 */
	@Autowired
	private CaseMasterRepository caseRepo;

	/**
	 * This Field is used to Inject PlanSelectedMasterRepository Object
	 */
	@Autowired
	private PlanSelectedMasterRepository planSelRepo;

	/**
	 * This Field is used to Inject CcapPlanMasterRepository Object
	 */
	@Autowired
	private CcapPlanMasterRepository ccapPlanRepo;

	/**
	 * This method is used to getApplicantData by regNumber
	 * 
	 * @param Integer
	 * @return ApplicantModel
	 */
	@Override
	public ApplicantModel getApplicantData(Integer regNumber) {
		// Variable Declaration
		Optional<ApplicantEntity> appEntity = null;
		ApplicantModel appModel = null;

		// Calling AR Repository method
		appEntity = appRegRepo.findById(regNumber);

		// NULL Check
		if (appEntity.isPresent()) {

			// create Object for ApplicantModel
			appModel = new ApplicantModel();

			// convert appEntity to appModel
			BeanUtils.copyProperties(appEntity.get(), appModel);
		}

		// Return appModel
		return appModel;
	}

	/**
	 * This method is used to createCase
	 * 
	 * @param CaseModel
	 * @return Integer
	 * 
	 */
	@Override
	public Integer createCase(CaseModel caseModel) {
		// Variable Declaration
		CaseEntity caseEntity = new CaseEntity();

		// NULL Check
		if (caseModel != null) {

			// Convert caseModel to caseEntity
			BeanUtils.copyProperties(caseModel, caseEntity);

			// NULL Check
			if (caseEntity != null) {
				caseEntity = caseRepo.save(caseEntity);
			}

		}
		// Return CaseNumber
		return caseEntity.getCaseNumber();
	}

	/**
	 * 
	 * This Method is used to get All Plans
	 * 
	 * @return List<String>
	 * 
	 */
	@Override
	public List<String> getAllPlans() {
		// Variable Declaration
		List<String> planList = null;

		// calling Repo method
		planList = caseRepo.findAllPlan();

		// NULL Check
		if (!planList.isEmpty()) {
			return planList;
		} else {
			return null;
		}
	}

	/**
	 * This Method is used to save SelectedPlan with caseNumber
	 * 
	 * @param PlanSElectedModel
	 * @return void
	 *
	 */
	@Override
	public void saveSelectedPlan(PlanSelectedModel planSelModel) {
		// Variable Declaration
		PlanSelectedEntity planSelEntity = null;

		// create Object for PlanSelectedEntity
		planSelEntity = new PlanSelectedEntity();

		// NULL Check
		if (planSelModel != null)

			// Convert planSelModel to planSelEntity
			BeanUtils.copyProperties(planSelModel, planSelEntity);

		// NULL Check
		if (planSelEntity != null)

			// Save the Record
			planSelRepo.save(planSelEntity);
	}

	@Override
	public void saveCcapPlanData(CcapPlanDataModel ccapModel) {
		// Variable Declaration
		CcapPlanDataEntity ccapEntity = null;
		EligibilityDetermination edRequest = null;
		Optional<PlanSelectedEntity> planSelectedEntity = null;
		CitigenData citigenData = null;
		PlanDetails planDetails = null;
		CcapPlanDataModel ccapPlanDataModel = null;
		CcapPlanData ccapRequest = null;
		Optional<CaseEntity> caseEntity = null;
		CaseModel caseModel= null;

		
		// Create ccapEnitty Object
		ccapEntity = new CcapPlanDataEntity();

		// convert ccapModel to ccapEntity
		BeanUtils.copyProperties(ccapModel, ccapEntity);

		// Save ccap plan data and get stored data
		ccapEntity = ccapPlanRepo.save(ccapEntity);

		
		// create Object for CcapPlanDataModel
		ccapPlanDataModel = new CcapPlanDataModel();

		// copy CcapEntity to CcapPlanDataModel
		BeanUtils.copyProperties(ccapEntity, ccapPlanDataModel);

		
		// create Object for CcapPlanData - Request
		ccapRequest = new CcapPlanData();

		// copy CcapPlanDataModel to CcapPlanData- Request
		BeanUtils.copyProperties(ccapPlanDataModel, ccapRequest);

		
		// Create PlanDetails Object
		planDetails = new PlanDetails();

		// set CcapPlan Data to PlanDetails
		planDetails.setCcapPlanData(ccapRequest);

		
		// create EligibilityDeterminationModel object
		edRequest = new EligibilityDetermination();
		
		// set planDetails to Eligibility Model
		edRequest.setPlanDetails(planDetails);

		
		
		// get case details
		caseEntity = caseRepo.findById(ccapModel.getCaseNumber());

		
		//create object for CaseModel 
		caseModel = new CaseModel();
		
		// copy caseEntity to EDModel
		BeanUtils.copyProperties(caseEntity.get(), caseModel);

		
		// Get static inner class object - CitizenData
		citigenData = new CitigenData();
		
		//copy caseModel to citigenData - Request
		BeanUtils.copyProperties(caseModel, citigenData);
		
		
		// Get Selected Plan
		planSelectedEntity = planSelRepo.findById(ccapModel.getCaseNumber());

		// Copy PlanSelectedEntity to citigenData
		BeanUtils.copyProperties(planSelectedEntity.get(), citigenData);

		// set citigenData to Eligibility Details
		edRequest.setCitigenData(citigenData);

		
		
		//create  Object for PlanInfo - Response
		PlanInfo planInfo = null;

		//Create Object for restTemplate
		RestTemplate restTemp = new RestTemplate();

		//NULL Check
		if (edRequest != null)
			
			//Make a RestCall to get Eligibility Data - Response
			planInfo = restTemp.postForObject("http://localhost:9092/getEligibility", edRequest, PlanInfo.class);

		System.out.println(planInfo);
	}

}
