package com.usa.his.admin.service;

import java.util.List;

import com.usa.his.admin.model.PlanModel;

/**
 * 
 * @author AHMED
 * 
 * 
 *         This interface is created for PlanServiceImpl
 *
 */
public interface PlanService {

	/**
	 * This Abstract method is used to savePlan
	 * 
	 * @param planModel
	 * @return Boolean
	 * 
	 */
	public Boolean savePlan(final PlanModel planModel);
	
	/**
	 * This Abstract method is used to get All Plans List
	 * 
	 * @return PlanModel
	 */
	public List<PlanModel> getAllPlans();
}
