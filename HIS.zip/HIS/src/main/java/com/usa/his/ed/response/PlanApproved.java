package com.usa.his.ed.response;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 * 
 * @author AHMED
 * 
 * This is a Response class for PlanApproved
 * 
 */

/**
 * <p>
 * Java class for anonymous complex type.
 * 
 * <p>
 * The following schema fragment specifies the expected content contained within
 * this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="plan-start-date" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="plan-end-date" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="benefit-amt" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = { "planStartDate", "planEndDate", "benefitAmt" })
public class PlanApproved {

	@XmlElement(name = "plan-start-date", required = true)
	protected String planStartDate;
	@XmlElement(name = "plan-end-date", required = true)
	protected String planEndDate;
	@XmlElement(name = "benefit-amt")
	protected double benefitAmt;

	/**
	 * Gets the value of the planStartDate property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getPlanStartDate() {
		return planStartDate;
	}

	/**
	 * Sets the value of the planStartDate property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setPlanStartDate(String value) {
		this.planStartDate = value;
	}

	/**
	 * Gets the value of the planEndDate property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getPlanEndDate() {
		return planEndDate;
	}

	/**
	 * Sets the value of the planEndDate property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setPlanEndDate(String value) {
		this.planEndDate = value;
	}

	/**
	 * Gets the value of the benefitAmt property.
	 * 
	 */
	public double getBenefitAmt() {
		return benefitAmt;
	}

	/**
	 * Sets the value of the benefitAmt property.
	 * 
	 */
	public void setBenefitAmt(double value) {
		this.benefitAmt = value;
	}

	@Override
	public String toString() {
		return "PlanApproved [planStartDate=" + planStartDate + ", planEndDate=" + planEndDate + ", benefitAmt="
				+ benefitAmt  + "]";
	}
	
	

}
