package com.usa.his.admin.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import lombok.Data;

/**
 * 
 * @author AHMED
 * 
 * 
 *         This Entity Class is used for Account Entity
 *
 */
@Data
@Entity
@Table(name = "ACCOUNT_MASTER")
public class AccEntity {

	/**
	 * This Property is used for ID
	 */
	@Id
	@SequenceGenerator(name = "seq1", sequenceName = "ACC_SEQ", initialValue = 1, allocationSize = 1)
	@GeneratedValue(generator = "seq1", strategy = GenerationType.SEQUENCE)
	private Integer id;

	/**
	 * This Property is used for FIRST_NAME
	 */
	@Column(name = "FIRST_NAME", length = 25)
	private String firstName;

	/**
	 * This Property is used for LAST_NAME
	 */
	@Column(name = "LAST_NAME", length = 25)
	private String lastName;

	/**
	 * This Property is used for GENDER
	 */
	@Column(name = "GENDER", length = 7)
	private String gender;

	/**
	 * This Property is used for EMAIL
	 */
	@Column(name = "EMAIL", length = 25)
	private String email;

	/**
	 * This Property is used for PASSWORD
	 */
	@Column(name = "PASSWORD")
	private String password;

	/**
	 * This Property is used for DOB
	 */
	@Column(name = "DOB", length = 10)
	private String dob;

	/**
	 * This Property is used for SSN
	 */
	@Column(name = "SSN", length = 9)
	private Long ssn;

	/**
	 * This Property is used for MOBILE_NUMBER
	 */
	@Column(name = "MOBILE_NUMBER", length = 12)
	private Long mobileNumber;

	/**
	 * This Property is used for USER_ROLE
	 */
	@Column(name = "USER_ROLE", length = 15)
	private String userRole;

	/**
	 * This Property is used for TRG_SW (Y|N)
	 */
	@Column(name = "ACTIVE_SW", length = 1)
	private String activeSW;

	/**
	 * This Property is used for CREATION_DATE
	 */
	@Column(name = "CREATION_DATE")
	@CreationTimestamp
	private Date creationDate;

	/**
	 * This Property is used for UPDATED_DATE
	 */
	@Column(name = "UPDATED_DATE")
	@UpdateTimestamp
	private Date updatedDate;
}
