package com.usa.his.exceptions;

import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.util.ArrayList;
import java.util.List;

import javax.crypto.BadPaddingException;
import javax.crypto.NoSuchPaddingException;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.usa.his.ar.model.ApplicantModel;
import com.usa.his.util.AppConstantsUtils;

/**
 * 
 * @author AHMED
 * 
 * 
 *         This Class is used for Global Exceptional Handler
 *
 */

@Controller
@ControllerAdvice
public class AppExceptionHandler {

	/**
	 * This method is used to handle the All Exception
	 * 
	 * @param model
	 * @return String
	 * 
	 */
	@ExceptionHandler({ InvalidSsnNumber.class })
	public String invalidSsnNumberExceptionHandler(RedirectAttributes attributes) {

		attributes.addFlashAttribute("failMsg", "Invalid SSN Number... Try Again...!");
		
		return "redirect:/appRegFailed";
	}
	
	
	@GetMapping("/appRegFailed")
	public String appRegFailed(final Model model) {
		model.addAttribute("appModel", new ApplicantModel());
		formValues(model);
		
		return "applicant_registration";
	}

	@ExceptionHandler({ EncyptDecryptException.class, UnsupportedEncodingException.class, NoSuchPaddingException.class,
			InvalidAlgorithmParameterException.class, BadPaddingException.class, Exception.class })
	public String exceptionHandler(Model model) {

		model.addAttribute("errMsg", "Some Problem Occured, Plase Try Again After Sometimes...!");

		return "error";

	}

	/**
	 * This method is used to Bind Initial Values to the form
	 * 
	 * @param model
	 * 
	 */
	private void formValues(final Model model) {

		//LOGGER.debug("*** AccountController : formValues method Started ***");

		/**
		 * Variable Declaration
		 */
		List<String> genderList = null;

		/**
		 * This list is used to initialize Genders
		 */
		genderList = new ArrayList<String>(3);

		genderList.add("");
		genderList.add(AppConstantsUtils.MALE);
		genderList.add(AppConstantsUtils.FE_MALE);

		model.addAttribute(AppConstantsUtils.GENDERS, genderList);

	

	//	LOGGER.debug("*** AccountController : formValues method Ended ***");
		//LOGGER.info("*** AccountController : formValues method executed Successfully ***");
	}

}
