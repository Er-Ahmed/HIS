package com.usa.his.exceptions;

/**
 * 
 * @author AHMED
 * 
 *         This class is created to catch InvlaidSsnNumber Exception
 *
 */

public class InvalidSsnNumber extends RuntimeException {

	/**
	 * 
	 * constructor for InvlaidSsnNumber
	 * 
	 * @param msg
	 *
	 */
	public InvalidSsnNumber(String msg) {
		super(msg);
	}
}
