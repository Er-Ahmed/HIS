package com.usa.his.um.service;

import java.util.HashMap;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.usa.his.admin.entity.AccEntity;
import com.usa.his.admin.repository.AccountMasterRepository;
import com.usa.his.util.AppConstantsUtils;
import com.usa.his.util.AppProperties;
import com.usa.his.util.JavaMailUtils;
import com.usa.his.util.PasswordUtils;

/**
 * 
 * @author AHMED
 * 
 * 
 *         This class is created for LoginServiceImpl - Implementation Class
 *
 */
@Service
public class LoginServiceImpl implements LoginService {

	/**
	 * This is used to Generate Log messages
	 */
	private static final Logger LOGGER = LogManager.getLogger(LoginServiceImpl.class);

	/**
	 * This Property is used to Inject AccountMasterRepository Object
	 */
	@Autowired
	private AccountMasterRepository accRepo;

	/**
	 * This Property is used to Inject JavaMailUtils Object
	 */
	@Autowired
	private JavaMailUtils mailUtils;

	/**
	 * This Property is used to Inject AppProperties Object
	 */
	@Autowired
	private AppProperties props;
	
	/**
	 * This method is used to Authenticate the User
	 * 
	 * @param userId
	 * @param password
	 * @return Map
	 * 
	 */
	@Override
	public Map<String, String> authenticateUser(String userId, String password) throws Exception {

		LOGGER.debug("*** LoginServiceImpl : authenticateUser method Started ***");

		// Variable Declaration
		AccEntity accEntity = null;
		String decryptedPass = null;
		Map<String, String> map = null;

		// Object creations
		accEntity = new AccEntity();
		map = new HashMap<String, String>();

		// get Account Details using UserId (Email)
		accEntity = accRepo.getAccountByEmail(userId);

		// Null Check
		if (accEntity != null) {

			// Decrypt the password stored in DB
			decryptedPass = PasswordUtils.decryptePassword(accEntity.getPassword());

			// Password Check
			if (password.equals(decryptedPass)) {

				// Account Status Check
				if (accEntity.getActiveSW().equals(AppConstantsUtils.ACC_SW_Y)) {

					// Check The Role (CW or ADMIN)
					if (accEntity.getUserRole().equals(AppConstantsUtils.ADMIN)) {
						map.put(AppConstantsUtils.ACCOUNT, AppConstantsUtils.ADMIN);
						System.out.println(AppConstantsUtils.ADMIN);

					} else {
						map.put(AppConstantsUtils.ACCOUNT, AppConstantsUtils.CASE_WORKER);
						System.out.println(AppConstantsUtils.CASE_WORKER);

					}
				} else {
					map.put(AppConstantsUtils.ACCOUNT, AppConstantsUtils.DE_ACTIVATED);

				}
			} else {
				map.put(AppConstantsUtils.ACCOUNT, AppConstantsUtils.INVALID);

			}
		} else {
			map.put(AppConstantsUtils.ACCOUNT, AppConstantsUtils.INVALID);

		}

		LOGGER.debug("*** LoginServiceImpl : authenticateUser method Ended ***");
		LOGGER.info("*** LoginServiceImpl : authenticateUser method Loaded Successfully ***");

		// Return Map
		return map;
	}

	/**
	 * 
	 * This method is used to check the Email is present or not for Password
	 * Recovery
	 * 
	 * @param userId
	 * @return String
	 * 
	 */
	@Override
	public String sendPasswordRecoveryMail(String userId) throws Exception {

		LOGGER.debug("*** LoginServiceImpl : sendPasswordRecoveryMail method Started ***");

		// variable Declaration
		AccEntity accEntity = null;
		String decryptedPassword = null;
		Boolean flag = false;

		// check for Email
		accEntity = accRepo.getAccountByEmail(userId);

		// Null Check
		if (accEntity != null) {

			// get password and decrypt it
			decryptedPassword = PasswordUtils.decryptePassword(accEntity.getPassword());

			// set decrypted password to accEntity
			accEntity.setPassword(decryptedPassword);

			// Send the Password on the Email
			mailUtils.sendEmail(accEntity);

			//set flat TRUE if accEntity not NULL
			flag = true;

		}
		
		LOGGER.debug("*** LoginServiceImpl : sendPasswordRecoveryMail method Ended ***");
		LOGGER.info("*** LoginServiceImpl : sendPasswordRecoveryMail method Loaded Successfully ***");

		if (flag == true) {
			return props.getProperties().get(AppConstantsUtils.RECOVERY_PASS_SENT_MSG);
			
		} else {
			// if no account found on given userId
			return props.getProperties().get(AppConstantsUtils.INVALID_USER_ID_MSG);
		}
	}
}
