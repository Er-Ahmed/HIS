package com.usa.his.dc.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import lombok.Data;

/**
 * 
 * @author AHMED
 * 
 * This class is used for Ccap Plan Data Entity
 */


@Data
@Entity
@Table(name="CCAP_PLAN_DATA_MASTER")
public class CcapPlanDataEntity {

	@Id
	@SequenceGenerator(name="gen1", sequenceName="CCAP_PLAN_DATA_SEQ", allocationSize=1, initialValue=1)
	@GeneratedValue(generator="gen1", strategy=GenerationType.SEQUENCE)
	private int id;
	
	@Column(name="KIDS_COUNT")
	private int kidsCount;
	
	@Column(name="KIDS_AGE")
	private int kidsAge;
	
	@Column(name="PARENTS_EMPLOYED")
	private String parentsEmployed;
	
	@Column(name="FAMILY_INCOME")
	private double familyIncome;
	
	@Column(name="CASE_NUMBER")
	private Integer caseNumber;
	
	@CreationTimestamp
	@Temporal(TemporalType.DATE)
	@Column(name="CREATION_DATE")
	private Date creationDate;
	
	@UpdateTimestamp
	@Temporal(TemporalType.DATE)
	@Column(name="UPDATION_DATE")
	private Date updationDate;


}