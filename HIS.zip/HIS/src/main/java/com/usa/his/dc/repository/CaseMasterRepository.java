package com.usa.his.dc.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.usa.his.dc.entity.CaseEntity;

/**
 * 
 * @author AHMED
 * 
 * This interface is created for CASE_MASTER Table
 *
 */
@Repository
public interface CaseMasterRepository extends JpaRepository<CaseEntity, Integer> {

	@Query(value="SELECT planName FROM PlanEntity")
	public List<String> findAllPlan();
	
	
}
