package com.usa.his.ar.model;

import java.util.Date;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import lombok.Data;

/**
 * 
 * @author AHMED
 * 
 * 
 *         This class is created for Applicant Model
 *
 */

@Data
public class ApplicantModel {

	/**
	 * This Field is used for REG_NUMBER
	 */
	private Integer regNumber;

	/**
	 * This Field is used for FIRST_NAME
	 */
	@NotEmpty(message="Enter Applicant First Name")
	private String firstName;

	/**
	 * This Field is used for LAST_NAME
	 */
	@NotEmpty (message= "Enter Applicant Last Name")
	private String lastName;

	/**
	 * This Field is used for GENDER
	 */
	@NotEmpty(message="Select Applicant Gender")
	private String gender;

	/**
	 * This Field is sued for DOB
	 */
	@NotEmpty(message="Select Date Of Birth")
	private String dob;
	
	/**
	 * This Field is used for EMAIL
	 */
	@NotEmpty(message = "Enter Applicant Email")
	private String email;

	/**
	 * This Field is used for SSN
	 */
	@NotNull(message="Enter Applicant SSN")
	private Long ssn;

	/**
	 * This Field is used for MOBILE_NUMBER
	 */
	@NotNull(message="Enter Applicant Mobile Number")
	private Long mobileNumber;

	
	/**
	 * This Field is used for CREATION_DATE
	 */
	private Date creationDate;

	/**
	 * This Field is used for UPDATION_DATE
	 */
	private Date updationDate;
}
