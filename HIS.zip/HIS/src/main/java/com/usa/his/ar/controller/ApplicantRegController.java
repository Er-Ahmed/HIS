package com.usa.his.ar.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.info.ProjectInfoProperties;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.usa.his.ar.entity.ApplicantEntity;
import com.usa.his.ar.model.ApplicantModel;
import com.usa.his.ar.service.ApplicantService;
import com.usa.his.exceptions.InvalidSsnNumber;
import com.usa.his.util.AppConstantsUtils;
import com.usa.his.util.AppProperties;

/**
 * 
 * @author AHMED
 * 
 *         This class is used to handle all Request Related to Applicant
 *
 */
@Controller
public class ApplicantRegController {

	/**
	 * This is used to Generate Log messages
	 */
	private static final Logger LOGGER = LogManager.getLogger(ApplicantRegController.class);

	/**
	 * This Field is used to Inject ApplicantService Object
	 */
	@Autowired
	private ApplicantService appService;

	/**
	 * This Filed is used to Inject AppProperties Object
	 */
	@Autowired
	private AppProperties appProps;

	/**
	 * 
	 * This method is used to show ApplicantRegistration Form
	 * 
	 * @param model
	 * @return String
	 * 
	 */

	@GetMapping("/applicantController")
	public String showApplicantRegForm(final Model model) {

		LOGGER.debug("*** ApplicantRegController :  showApplicantRegForm method Started ***");

		// Add model Object to Model Attribute
		model.addAttribute(AppConstantsUtils.APP_MODEL, new ApplicantModel());

		// Initialize formValues
		formValues(model);

		// To show Admin Link in NavBar
		model.addAttribute(AppConstantsUtils.ACCOUNT, AppConstantsUtils.ADMIN);
				 
		LOGGER.debug("*** ApplicantRegController : showApplicantRegForm method Ended ***");
		LOGGER.info("*** ApplicantRegController : showApplicantRegForm method executed Successfully ***");

		// return View Name
		return AppConstantsUtils.APPLICANT_REG_VIEW;
	}

	/**
	 * 
	 * This methods is used to process application Registration
	 * 
	 * @param appModel
	 * @param error
	 * @param model
	 * @param attributes
	 * @return String
	 * 
	 */
	@PostMapping("applicantRegister")
	public String applicantRegistration(
			@Valid @ModelAttribute(AppConstantsUtils.APP_MODEL) final ApplicantModel appModel,
			final BindingResult error, final Model model, final RedirectAttributes attributes) {

		LOGGER.debug("*** ApplicantRegController :  applicantRegistration method Started ***");

		if (error.hasErrors()) {
			// Initialize formValues
			formValues(model);

			return AppConstantsUtils.APPLICANT_REG_VIEW;
		}
		// Variable Declaration
		Map<String, String> map = null;

		// check for Duplicate SSN Entry for Plan
		String result = appService.checkForSSN(appModel.getSsn());

		// NULL Check
		if (result != null) {

			// if Duplicate
			if (result.equals(AppConstantsUtils.DUPLICATE)) {

				// add message to modelAttribute
				model.addAttribute(AppConstantsUtils.FAIL_MSG,
						appProps.getProperties().get(AppConstantsUtils.DUPLICATE_SSN_HOLDER));

				// Initialize formValues
				formValues(model);

				LOGGER.debug("*** ApplicantRegController : applicantRegistration method Ended ***");
				LOGGER.info("*** ApplicantRegController : applicantRegistration method executed Successfully ***");

				// return View Name
				return AppConstantsUtils.APPLICANT_REG_VIEW;
			}
		}

		try {

			// call Service method to Register
			map = appService.applicantRegistration(appModel);

		} catch (Exception e) {

			LOGGER.error("*** ApplicantRegController :  applicantRegistration Got Exception ***");

			throw new InvalidSsnNumber("**** Exception Occur While Encrypting Decrypting the Password ***");
		}

		if (map.containsKey(AppConstantsUtils.SUCCESS)) {
			// set date to RedirectAttribute
			attributes.addFlashAttribute(AppConstantsUtils.SUCC_MSG, map.get(AppConstantsUtils.SUCCESS));

		} else if (map.containsKey("FAIL")) {
			// set date to RedirectAttribute
			attributes.addFlashAttribute(AppConstantsUtils.FAIL_MSG, map.get(AppConstantsUtils.FAIL));

		} else {
			// set date to RedirectAttribute
			attributes.addFlashAttribute(AppConstantsUtils.FAIL_MSG, map.get(AppConstantsUtils.WRONG_STATE));
		}

		// To show Admin Link in NavBar
		 model.addAttribute(AppConstantsUtils.ACCOUNT, AppConstantsUtils.ADMIN);
				 
		LOGGER.debug("*** ApplicantRegController : applicantRegistration method Ended ***");
		LOGGER.info("*** ApplicantRegController : applicantRegistration method executed Successfully ***");

		// redirect to get method to avoid double post
		return AppConstantsUtils.REDIRET_APP_REG_SUSS;
	}

	/**
	 * 
	 * This method is used to Avoid Double Posting Problem
	 * 
	 * @param model
	 * @return String
	 * 
	 */
	@GetMapping("/appRegSuccess")
	public String applicantRegSucess(final Model model) {

		LOGGER.debug("*** ApplicantRegController :  applicantRegSucess method Started ***");

		// add model object to ModelAttribute
		model.addAttribute(AppConstantsUtils.APP_MODEL, new ApplicantModel());

		// Initialize formValues
		formValues(model);

		LOGGER.debug("*** ApplicantRegController : applicantRegSucess method Ended ***");
		LOGGER.info("*** ApplicantRegController : applicantRegSucess method executed Successfully ***");

		// return View Name
		return AppConstantsUtils.APPLICANT_REG_VIEW;
	}

	/**
	 * This method is used to Bind Initial Values to the form
	 * 
	 * @param model
	 * 
	 */
	private void formValues(final Model model) {

		LOGGER.debug("*** ApplicantRegController : formValues method Started ***");

		/**
		 * Variable Declaration
		 */
		List<String> genderList = null;

		/**
		 * This list is used to initialize Genders
		 */
		genderList = new ArrayList<String>(3);

		genderList.add("");
		genderList.add(AppConstantsUtils.MALE);
		genderList.add(AppConstantsUtils.FE_MALE);

		model.addAttribute(AppConstantsUtils.GENDERS, genderList);

		LOGGER.debug("*** ApplicantRegController : formValues method Ended ***");
		LOGGER.info("*** ApplicantRegController : formValues method executed Successfully ***");

	}

	/**
	 * This method is used to get all Registered User Details
	 * 
	 * @param model
	 * @return String
	 */

	@GetMapping("/viewAppList")
	public String viewAppList(final HttpServletRequest req, final Model model) {

		LOGGER.debug("*** ApplicantRegController : viewAppList method Started ***");

		//Variable Declaration
		Page<ApplicantEntity> pageData = null;
		List<ApplicantModel> appModelList = new ArrayList<ApplicantModel>();

		String pgNo = null;
		String orderName = null;
		String orderType = null;

		Integer pageNo = 1;
		Integer tp = null;

		//Storing request Scope date
		pgNo = req.getParameter(AppConstantsUtils.PG_NO);
		orderName = req.getParameter(AppConstantsUtils.ORDER_NAME);
		orderType = req.getParameter(AppConstantsUtils.ORDER_TYPE);

		//NULL Check
		if (pgNo != null) {
			pageNo = Integer.parseInt(pgNo);
		}

		//Calling Service Method
		pageData = appService.retriveAllApplicant(pageNo - 1, orderName, orderType);

		//Converting pageData to appModelList
		pageData.forEach(appEntity -> {
			ApplicantModel appModel = new ApplicantModel();
			BeanUtils.copyProperties(appEntity, appModel);
			appModelList.add(appModel);
		});

		//setting Total Page Count
		tp = pageData.getTotalPages();

		// To show Admin Link in NavBar
		 model.addAttribute(AppConstantsUtils.ACCOUNT, AppConstantsUtils.ADMIN);

		//Adding List to Model Attribute
		model.addAttribute(AppConstantsUtils.APP_MODEL_LIST, appModelList);

		//Adding Total Page count to Model Attribute
		model.addAttribute("tp", tp);

		//Adding Current Page to Model Attribute
		model.addAttribute("cp", pageNo);

		LOGGER.debug("*** ApplicantRegController : viewAppList method Ended ***");
		LOGGER.info("*** ApplicantRegController : viewAppList method executed Successfully ***");

		//Return View 
		return AppConstantsUtils.APP_LIST_VIEW;
	}

	/**
	 * 
	 * This method is used for Searching
	 * 
	 * @param req
	 * @param model
	 * @param attributes
	 * @return String
	 * 
	 */
	@GetMapping("/searching")
	public String searching(final HttpServletRequest req, Model model, RedirectAttributes attributes) {
		
		LOGGER.debug("*** ApplicantRegController : searching method Started ***");
		
		//Variable Declaration
		String searchBy = null;
		String searchTxt = null;

		List<ApplicantModel> appModelList = new ArrayList<>();
		ApplicantModel appModel = null;

		//Getting Data From Request Scope
		searchBy = req.getParameter(AppConstantsUtils.SEARCH_BY);
		searchTxt = req.getParameter(AppConstantsUtils.TEXT);

		//NULL Check
		if (searchTxt.equals("") || searchTxt == null) {
			return AppConstantsUtils.REDIRECT_APP_LIST_VIEW;
		}
		
		//Searching for Single Record
		if ((searchBy.equals(AppConstantsUtils.REG_NUMBER) || (searchBy.equals(AppConstantsUtils.SSN)) || (searchBy.equals(AppConstantsUtils.EMAIL)))) {
			
			//Calling Service Method
			appModel = appService.searching(searchBy, searchTxt);
			
			//NULL Check
			if(appModel==null) {
				attributes.addFlashAttribute(AppConstantsUtils.MSG,appProps.getProperties().get(AppConstantsUtils.SEARCH_NOT_FOUND));
				return AppConstantsUtils.REDIRECT_APP_LIST_VIEW;
			}	
		} 
		
		//Searching for Multiple Records
		else {
			//Calling Service Method
			appModelList = appService.searchingList(searchBy, searchTxt);
			
			//NULL Check
			if(appModelList==null) {
				attributes.addFlashAttribute(AppConstantsUtils.MSG,appProps.getProperties().get(AppConstantsUtils.SEARCH_NOT_FOUND));
				return AppConstantsUtils.REDIRECT_APP_LIST_VIEW;
			}
		}

		//Adding Model Data to List
		appModelList.add(appModel);
		
		//Adding List to Model Attribute
		model.addAttribute(AppConstantsUtils.APP_MODEL_LIST, appModelList);
		
		LOGGER.debug("*** ApplicantRegController : searching method Ended ***");
		LOGGER.info("*** ApplicantRegController : searching method executed Successfully ***");
		
		//Return View
		return AppConstantsUtils.APP_LIST_VIEW;
	}

}
