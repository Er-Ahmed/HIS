package com.usa.his.util;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.mail.internet.MimeMessage;

import org.apache.commons.text.StringSubstitutor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;

import com.usa.his.admin.entity.AccEntity;
import com.usa.his.admin.model.AccModel;

/**
 * 
 * @author AHMED
 * 
 * 
 *         This class is created for JavaMailUtils - Helper Class
 *
 */
@Component
public class JavaMailUtils {

	/**
	 * 
	 * This is used to Generate Log messages
	 * 
	 */
	private final Logger LOGGER = LogManager.getLogger(JavaMailUtils.class);

	/**
	 * 
	 * This field is used to Inject JavaMailsender Object
	 * 
	 */
	@Autowired
	private JavaMailSender sender;

	/**
	 * 
	 * This field is used to Inject AppProperties Object
	 * 
	 */
	@Autowired
	private AppProperties props;

	/**
	 * 
	 * This method is used to Send The Account Registration Email
	 * 
	 */
	public void sendEmail(AccModel userModel) {
		LOGGER.debug("*** JavaMailUtils : sendEmail method Started ***");

		String emailBody = null;
		emailBody = emailBody(userModel);

		try {
			triggerMail(emailBody, "er.ahmedsk@gmail.com", "User Created");

			LOGGER.debug("*** JavaMailUtils :  sendEmail method Ended ***");
			LOGGER.info("*** JavaMailUtils :  sendEmail method executed Successfully ***");

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**
	 * 
	 * This is an helper method to Produce Body for Mail By Reading the File &
	 * Replacing the Content
	 *
	 * @param userModel
	 * @return String
	 * 
	 */
	private String emailBody(AccModel userModel) {

		LOGGER.debug("*** JavaMailUtils : emailBody method Started ***");

		/**
		 * Variable Declaration
		 */
		Map<String, String> valuesMap = null;
		String fileText = "";

		StringSubstitutor stringSub = null;
		String modifiedText = "";

		/**
		 * Reading File Name with Path
		 */
		String fileName = props.getProperties().get(AppConstantsUtils.ACC_CREATION_EMAIL_BODY_TEMP);

		/**
		 * Executing Logic to Read TXT file and Replace the Content using
		 * try-with-resource
		 */

		valuesMap = new HashMap<String, String>();

		valuesMap.put("FNAME", userModel.getFirstName());
		valuesMap.put("LNAME", userModel.getLastName());
		valuesMap.put("URL", AppConstantsUtils.HIS_URL);
		valuesMap.put("EMAIL", userModel.getEmail());
		valuesMap.put("PWD", userModel.getPassword());
		valuesMap.put("ROLE", userModel.getUserRole());
		valuesMap.put("PHNO", AppConstantsUtils.HIS_ADMIN_PHNO);

		try {

			/**
			 * Read the At Once
			 */
			fileText = new String(Files.readAllBytes(Paths.get(fileName)));

			/**
			 * Get All Values from Map And Set to StringSubstitutor
			 */
			stringSub = new StringSubstitutor(valuesMap);

			/**
			 * Modify the Original Content
			 */
			modifiedText = stringSub.replace(fileText);

		}

		catch (Exception e) {
			e.printStackTrace();
		}

		/**
		 * Return Mail Body as String
		 */
		return modifiedText;
	}

	/**
	 * 
	 * This is An Helper method to Trigger the Mail with Given Input Parameters
	 * 
	 * @param msg
	 * @param senderMailId
	 * @param subject
	 * @param edModel
	 * @throws Exception
	 * 
	 * 
	 */
	private void triggerMail(String emailBody, String senderMailId, String subject) throws Exception {

		LOGGER.debug("*** JavaMailUtils : triggerMail method Started ***");

		MimeMessage message = null;
		MimeMessageHelper helper = null;
		message = sender.createMimeMessage();
		helper = new MimeMessageHelper(message, true);
		helper.setTo(senderMailId);
		helper.setSentDate(new Date());
		helper.setSubject(subject);
		helper.setText(emailBody, true);

		/**
		 * Send Mail
		 */
		sender.send(message);

		LOGGER.debug("*** JavaMailUtils :  triggerMail method Ended ***");
		LOGGER.info("*** JavaMailUtils :  triggerMail method executed Successfully ***");

	}

	/**
	 * 
	 * This method is used to Send The Account Registration Email
	 * 
	 */
	public void sendEmail(AccEntity accEntity) {
		LOGGER.debug("*** JavaMailUtils : sendEmail method Started ***");

		String emailBody = null;
		emailBody = emailBody(accEntity);

		try {
			triggerMail(emailBody, "er.ahmedsk@gmail.com", "User Created");

			LOGGER.debug("*** JavaMailUtils :  sendEmail method Ended ***");
			LOGGER.info("*** JavaMailUtils :  sendEmail method executed Successfully ***");

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**
	 * 
	 * This is an helper method to Produce Body for Mail By Reading the File &
	 * Replacing the Content
	 *
	 * @param userModel
	 * @return String
	 * 
	 */
	private String emailBody(AccEntity accEntity) {

		LOGGER.debug("*** JavaMailUtils : emailBody method Started ***");

		/**
		 * Variable Declaration
		 */
		Map<String, String> valuesMap = null;
		String fileText = "";

		StringSubstitutor stringSub = null;
		String modifiedText = "";

		/**
		 * Reading File Name with Path
		 */
		String fileName = props.getProperties().get(AppConstantsUtils.PASS_RECOVERY_EMAIL_BODY_TEMP);

		/**
		 * Executing Logic to Read TXT file and Replace the Content using
		 * try-with-resource
		 */

		valuesMap = new HashMap<String, String>();

		valuesMap.put("FNAME", accEntity.getFirstName());
		valuesMap.put("LNAME", accEntity.getLastName());
		valuesMap.put("URL", AppConstantsUtils.HIS_URL);
		valuesMap.put("EMAIL", accEntity.getEmail());
		valuesMap.put("PWD", accEntity.getPassword());
		valuesMap.put("ROLE", accEntity.getUserRole());
		valuesMap.put("PHNO", AppConstantsUtils.HIS_ADMIN_PHNO);

		try {

			/**
			 * Read the At Once
			 */
			fileText = new String(Files.readAllBytes(Paths.get(fileName)));

			/**
			 * Get All Values from Map And Set to StringSubstitutor
			 */
			stringSub = new StringSubstitutor(valuesMap);

			/**
			 * Modify the Original Content
			 */
			modifiedText = stringSub.replace(fileText);

		}

		catch (Exception e) {
			e.printStackTrace();
		}

		/**
		 * Return Mail Body as String
		 */
		return modifiedText;
	}

}