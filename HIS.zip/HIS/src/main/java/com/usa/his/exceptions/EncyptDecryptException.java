package com.usa.his.exceptions;

/**
 * This class is used to Deal with Encryption Decryption Exceptions
 * 
 * @author AHMED
 *
 */
public class EncyptDecryptException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 666641L;

	/**
	 * Constructor for EncrypDecryptException
	 * 
	 * 
	 * @param msg
	 */
	public EncyptDecryptException(String msg) {
		super(msg);
	}
}
