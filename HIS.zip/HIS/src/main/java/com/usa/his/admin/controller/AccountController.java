package com.usa.his.admin.controller;

import java.util.Arrays;
import java.util.List;

import javax.validation.Valid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.usa.his.admin.model.AccModel;
import com.usa.his.admin.service.AccService;
import com.usa.his.exceptions.EncyptDecryptException;
import com.usa.his.util.AppConstantsUtils;
import com.usa.his.util.AppProperties;

/**
 * 
 * @author AHMED
 * 
 * 
 *         This class is created for AccountController
 *
 */

@Controller
public class AccountController {
	/**
	 * This is used to Generate Log messages
	 */
	private static final Logger LOGGER = LogManager.getLogger(AccountController.class);

	/**
	 * This Property is used to Inject AccService class Object
	 */
	@Autowired
	private AccService accService;

	/**
	 * This Property is used to Inject AppProperties class Object
	 */
	@Autowired
	private AppProperties props;

	/**
	 * This method is used to load User Registration Form
	 * 
	 * @param accModel
	 * @return String
	 */
	@GetMapping("/accountRegistration")
	public String showAccountRegistrationForm(@ModelAttribute(AppConstantsUtils.ACC_MODEL) final AccModel accModel,
			final Model model) {

		LOGGER.debug("*** AccountController : showAccountRegistrationForm method Started ***");

		//To show Admin Link in NavBar
		model.addAttribute(AppConstantsUtils.ACCOUNT, AppConstantsUtils.ADMIN);
		
		formValues(model);

		LOGGER.debug("*** AccountController : showAccountRegistrationForm method Ended ***");
		LOGGER.info("*** AccountController : showAccountRegistrationForm method Loaded Successfully ***");

		return AppConstantsUtils.REG_FORM_VIEW;
	}

	/**
	 * This method is used to process the form Data
	 * 
	 * @param accModel
	 * @param errors
	 * @param model
	 * @param attribute
	 * @return String
	 * 
	 */
	@PostMapping("accRegister")
	public String processAccountRegistration(
			@Valid @ModelAttribute(AppConstantsUtils.ACC_MODEL) final AccModel accModel, final BindingResult errors,
			final Model model, final RedirectAttributes attribute) {

		LOGGER.debug("*** AccountController : processAccountRegistration method Started ***");
		/**
		 * Variable Declaration
		 */
		Boolean result = null;

		/**
		 * Validation Check
		 */
		if (errors.hasErrors()) {
			formValues(model);
			return AppConstantsUtils.REG_FORM_VIEW;
		}

		/**
		 * Calling Service method
		 */
		try {
			result = accService.accRegistration(accModel);
		} catch (Exception e) {
			LOGGER.error("*** AccountController : processAccountRegistration method got Exception ***");
			throw new EncyptDecryptException("**** Exception Occur While Encrypting Decrypting the Password ***");
		}

		if (result == true) {
			attribute.addFlashAttribute(AppConstantsUtils.SUCC_MSG,
					accModel.getUserRole() + props.getProperties().get(AppConstantsUtils.ACC_REG_SUCC));
		} else {
			attribute.addFlashAttribute(AppConstantsUtils.FAIL_MSG,
					accModel.getUserRole() + props.getProperties().get(AppConstantsUtils.ACC_REG_FAIL));
		}

		//To show Admin Link in NavBar
		model.addAttribute(AppConstantsUtils.ACCOUNT, AppConstantsUtils.ADMIN);
				
		LOGGER.debug("*** AccountController : processAccountRegistration method Ended ***");
		LOGGER.info("*** AccountController : processAccountRegistration method executed Successfully ***");

		return AppConstantsUtils.REDIRECT_ACC_REG;
	}

	/**
	 * This method is used to avoid Double Posting of Same form
	 * 
	 * @param accModel
	 * @param model
	 * @return String
	 */
	@GetMapping("/accRegSuccess")
	public String accRegSuccess(@ModelAttribute(AppConstantsUtils.ACC_MODEL) final AccModel accModel,
			final Model model) {

		LOGGER.debug("*** AccountController : accRegSuccess method Started ***");

		//To show Admin Link in NavBar
		model.addAttribute(AppConstantsUtils.ACCOUNT, AppConstantsUtils.ADMIN);

		formValues(model);

		LOGGER.debug("*** AccountController : accRegSuccess method Ended ***");
		LOGGER.info("*** AccountController : accRegSuccess method executed Successfully ***");

		return AppConstantsUtils.REG_FORM_VIEW;
	}

	/**
	 * This method is used to Bind Initial Values to the form
	 * 
	 * @param model
	 * 
	 */
	private void formValues(final Model model) {

		LOGGER.debug("*** AccountController : formValues method Started ***");

		/**
		 * Variable Declaration
		 */
		List<String> genderList = null;
		List<String> userRoleList = null;

		/**
		 * This list is used to initialize Genders
		 */
		genderList = Arrays.asList("", AppConstantsUtils.MALE, AppConstantsUtils.FE_MALE);

		/*genderList.add("");
		genderList.add(AppConstantsUtils.MALE);
		genderList.add(AppConstantsUtils.FE_MALE);*/

		model.addAttribute(AppConstantsUtils.GENDERS, genderList);

		/**
		 * This list used to initialize UserRoles
		 */
		userRoleList = accService.getAccRolesList();

		model.addAttribute(AppConstantsUtils.ROLES, userRoleList);

		LOGGER.debug("*** AccountController : formValues method Ended ***");
		LOGGER.info("*** AccountController : formValues method executed Successfully ***");

	}

	/**
	 * This method is used to get all Registered User Details
	 * 
	 * @param model
	 * @return String
	 */

	@GetMapping("viewAccList")
	public String viewAccList(final Model model) {

		LOGGER.debug("*** AccountController : viewAccList method Started ***");

		List<AccModel> accModelList = null;

		accModelList = accService.getAllAccounts();
		
		//To show Admin Link in NavBar
		model.addAttribute(AppConstantsUtils.ACCOUNT, AppConstantsUtils.ADMIN);

		model.addAttribute(AppConstantsUtils.ACC_MODEL_LIST, accModelList);

		LOGGER.debug("*** AccountController : viewAccList method Ended ***");
		LOGGER.info("*** AccountController : viewAccList method executed Successfully ***");

		return AppConstantsUtils.ACC_LIST_VIEW;
	}

	/**
	 * 
	 * This method is used for UNIQUE emailValidation
	 * 
	 * @param email
	 * @return String
	 * 
	 * 
	 */
	@GetMapping("validateEmail")
	public @ResponseBody String emailValidation(final String email) {

		LOGGER.debug("*** AccountController : emailValidation method Started ***");

		String result = accService.checkForEmail(email);

		LOGGER.debug("*** AccountController : emailValidation method Ended ***");
		LOGGER.info("*** AccountController : emailValidation method executed Successfully ***");

		return result;
	}

	/**
	 * This method is used To De-Activate the Account
	 * 
	 * @param id
	 * @param attribute
	 * @return String
	 * 
	 */
	@GetMapping("deActivateAccount")
	public String deActivateAcc(@RequestParam(AppConstantsUtils.ID) final Integer id,
			final RedirectAttributes attribute) {

		LOGGER.debug("*** AccountController : deActiveUser method Started ***");

		String result = null;

		result = accService.deActiveAccountById(id);

		attribute.addFlashAttribute(AppConstantsUtils.ACC_MSG, result);

		LOGGER.debug("*** AccountController : deActivateAcc method Ended ***");
		LOGGER.info("*** AccountController : deActivateAcc method executed Successfully ***");

		return "redirect:/accountList";
	}

	/**
	 * This method is used To Activate the Account
	 * 
	 * @param id
	 * @param attribute
	 * @return String
	 * 
	 */
	@GetMapping("activateAccount")
	public String activeAccount(@RequestParam(AppConstantsUtils.ID) final Integer id,
			final RedirectAttributes attribute) {

		LOGGER.debug("*** AccountController : activeAccount method Started ***");

		String result = null;

		result = accService.activeAccountById(id);

		attribute.addFlashAttribute(AppConstantsUtils.ACC_MSG, result);

		LOGGER.debug("*** AccountController : activeAccount method Ended ***");
		LOGGER.info("*** AccountController : activeAccount method executed Successfully ***");

		return "redirect:/accountList";
	}

	/**
	 * This method is used to Redirect the Method
	 * 
	 * @param id
	 * @param attribute
	 * @return String
	 * 
	 */
	@GetMapping("/accountList")
	public String accountList(Model model) {

		LOGGER.debug("*** AccountController : accountList method Started ***");

		/**
		 * Variable Declaration
		 */
		List<AccModel> accModelList = null;

		/**
		 * Fetching the Account List
		 */
		accModelList = accService.getAllAccounts();

		model.addAttribute(AppConstantsUtils.ACC_MODEL_LIST, accModelList);

		//To show Admin Link in NavBar
		model.addAttribute(AppConstantsUtils.ACCOUNT, AppConstantsUtils.ADMIN);
				
		LOGGER.debug("*** AccountController : accountList method Ended ***");
		LOGGER.info("*** AccountController : accountList method executed Successfully ***");

		return AppConstantsUtils.ACC_LIST_VIEW;

	}

}
