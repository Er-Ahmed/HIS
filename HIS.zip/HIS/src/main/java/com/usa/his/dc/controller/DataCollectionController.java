package com.usa.his.dc.controller;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.usa.his.ar.model.ApplicantModel;
import com.usa.his.dc.model.CaseModel;
import com.usa.his.dc.model.CcapPlanDataModel;
import com.usa.his.dc.model.MedicaidPlanDataModel;
import com.usa.his.dc.model.PlanSelectedModel;
import com.usa.his.dc.model.SnapPlanDataModel;
import com.usa.his.dc.service.DataCollectionService;

/**
 * 
 * @author AHMED
 * 
 *         This class is created for DataCollection Controller It will Deal with
 *         all Requests and Responses
 *
 */
@Controller
public class DataCollectionController {

	/**
	 * This Field is used to Inject DataCollectionService Object
	 */
	@Autowired
	private DataCollectionService dcService;

	/**
	 * This method is used to display createCase Form
	 * 
	 * @param model
	 * @return String
	 * 
	 */

	@GetMapping("/showAppDetail")
	public String createCaseForm(final Model model) {

		return "create_case_view";
	}

	@GetMapping("getAppDetails")
	public String showAppDetails(final HttpServletRequest req, ApplicantModel appModel, final Model model,
			RedirectAttributes attributes) {
		// Variable Declaration
		String regNum = null;
		Integer regNumber = null;

		// store data from request scope
		regNum = req.getParameter("regNumber");

		// NULL Check
		if ((regNum.equals("")) || (regNum == null)) {
			attributes.addFlashAttribute("msg", "Please Enter Registration Number");
			return "redirect:/showAppDetail";

		} else {
			regNumber = Integer.parseInt(regNum);
		}

		// Call Service method
		appModel = dcService.getApplicantData(regNumber);

		System.out.println(appModel);
		// NULL Check
		if (appModel != null) {
			model.addAttribute("appModel", appModel);
		} else {
			model.addAttribute("msg", "Applicant Not Registered On This Number");
		}

		return "create_case_view";
	}

	@PostMapping("createCase")
	public String createCase(@ModelAttribute("caseModel") CaseModel caseModel, RedirectAttributes attributes) {
		// Variable Declaration
		Integer caseNumber = null;

		// Call Service Method
		caseNumber = dcService.createCase(caseModel);

		// NULL Check
		if (caseNumber != null) {
			attributes.addFlashAttribute("caseNumber", caseNumber);
			return "redirect:/selectPlan";
		} else {

			attributes.addFlashAttribute("msg", "Unable To Create Case... Please Try Again...!");
			return "redirect:/create_case_view";
		}
	}

	@GetMapping("/selectPlan")
	public String selectPlan(Model model) {
		// Variable Declaration
		List<String> planList = null;

		// calling Service method
		planList = dcService.getAllPlans();

		// NULL Check
		if (!planList.isEmpty()) {

			// add planList to model scope
			model.addAttribute("plans", planList);
			
			//add PlanSelectedModel to model scope
			model.addAttribute("planSelModel", new PlanSelectedModel());

		} else {
			// add message to model scope
			model.addAttribute("msg", "No plans Found");
		}
		return "select_plan_view";
	}

	@PostMapping("dataCollection")
	public String dataCollection(@ModelAttribute("planSelModel") PlanSelectedModel planSelModel, Model model) {
		// Variable Declaration
		Map<String, String> map = new HashMap<String, String>();

		// NULL Check
		if (planSelModel != null) {
			
			//calling Service method
			dcService.saveSelectedPlan(planSelModel);

			// if Select Plan is SNAP
			if (planSelModel.getPlanSelected().equals("Snap")) {
				
				//Initialize form Values
				List<String> isEmployed=Arrays.asList("","Y","N");
				
				//Add Values to model Scope
				model.addAttribute("isEmployed",isEmployed);
				
				//Add Empty Model Object to model Scope
				model.addAttribute("snapModel", new SnapPlanDataModel());
				
				//Return View
				map.put("plan_view", "snap_plan_data_collection");
				
				//if Selected Plan is CCAP
			} else if (planSelModel.getPlanSelected().equals("Ccap")) {
				
				//Initialize form Values
				List<String> parentsEmployed=Arrays.asList("","Y","N");
				
				//Add Values to model Scope
				model.addAttribute("parentsEmployed",parentsEmployed);
				
				//Add Empty Model Object to model Scope
				model.addAttribute("ccapModel", new CcapPlanDataModel());
				
				//Add CaseNumber to model Scope
				model.addAttribute("caseNumber", planSelModel.getCaseNumber());
				
				//Return view
				map.put("plan_view", "ccap_plan_data_collection");
				
				//if Select Plan is Medicaid
			} else if(planSelModel.getPlanSelected().equals("Medicaid")) {
				
				//Add Empty Model Object to model Scope
				model.addAttribute("medicaidModel", new MedicaidPlanDataModel());
				
				//Return view
				map.put("plan_view", "medicaid_plan_data_collection");
				
			}
		} else {
			model.addAttribute("msg", "Plan Not Selected");
			return "select_plan_view";
		}

		return map.get("plan_view");
	}
	
	@PostMapping("ccapPlan")
	public String ccapPlanProcess(@ModelAttribute("ccapModel")CcapPlanDataModel ccapModel) {
		//Variable Declaration
		System.out.println(ccapModel);
		
		//calling Service method
		dcService.saveCcapPlanData(ccapModel);
		
		return null;
	}
	
	@PostMapping("snapPlan")
	public String snapPlanProcess(@ModelAttribute("snapModel")SnapPlanDataModel snapModel) {
		//Variable Declaration
		
		
		System.out.println(snapModel);
		
		return null;
	}
	
	@PostMapping("medicaidPLan")
	public String medicaidPlanProcess(@ModelAttribute("medicaidModel")MedicaidPlanDataModel medicaidModel) {
		//Variable Declaration
		
		
		System.out.println(medicaidModel);
		
		
		return null;
	}

	
}
