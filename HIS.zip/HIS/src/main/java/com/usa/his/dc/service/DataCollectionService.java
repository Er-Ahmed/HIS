package com.usa.his.dc.service;

import java.util.List;

import com.usa.his.ar.model.ApplicantModel;
import com.usa.his.dc.model.CaseModel;
import com.usa.his.dc.model.CcapPlanDataModel;
import com.usa.his.dc.model.PlanSelectedModel;

/**
 * 
 * @author AHMED
 * 
 * This Interface is used DataCollectionServiceImpl
 *
 */
public interface DataCollectionService {

	/**
	 * This Abstract method is used to getApplicantData
	 * 
	 * @param regNumber
	 * @return ApplicantModel
	 * 
	 */
	public ApplicantModel getApplicantData(Integer regNumber);
	
	/**
	 * This Abstract method is used to create a Case
	 * 
	 * @param caseModel
	 * @return Integer
	 * 
	 */
	public Integer createCase(CaseModel caseModel);
	
	/**
	 * This Abstract method is used to get plan list
	 * 
	 * @return List<String>
	 */
	public List<String> getAllPlans();
	
	/**
	 * This Abstract method is used to save selectedPlan with caseNumber
	 * 
	 * @param PlanSelectedModel
	 * @return void
	 */
	public void saveSelectedPlan(PlanSelectedModel planSelModel);
	
	public void saveCcapPlanData(CcapPlanDataModel ccapModel);
	
	
}
