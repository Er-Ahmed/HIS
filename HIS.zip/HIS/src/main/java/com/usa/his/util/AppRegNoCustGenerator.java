package com.usa.his.util;

import java.io.Serializable;

import org.hibernate.HibernateException;
import org.hibernate.engine.spi.SharedSessionContractImplementor;
import org.hibernate.id.IdentifierGenerator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.usa.his.ar.repository.ApplicantRegMasterRepository;

/**
 * 
 * @author AHMED
 * 
 * This class is used to Application Registration Custom Gemerator
 *
 */
@Component
public class AppRegNoCustGenerator implements IdentifierGenerator {

	/**
	 * This Field is used to Inject ApplicantRegMasterRepository Object
	 */
	@Autowired
	private ApplicantRegMasterRepository appRegRepo;

	/**
	 * This method is used to Generate the Custom Registration Number
	 * 
	 * @param session
	 * @param Object
	 * @throws HibernarteException
	 * @return Serializable
	 */
	@Override
	public Serializable generate(SharedSessionContractImplementor session, Object object) throws HibernateException {
		// Variable Declaration
		Long seq_no = null;

		// get SEQ_NO From DB
		seq_no = appRegRepo.getSequenceNo();

		System.out.println(seq_no);
		if (seq_no <= 9)
			return "HIS_APP_REG_NO_000" + seq_no;

		else if (seq_no <= 99)
			return "HIS_APP_REG_NO_00" + seq_no;

		else if (seq_no <= 999)
			return "HIS_APP_REG_NO_0" + seq_no;

		else
			return "HIS_APP_REG_NO_" + seq_no;

	}

}
