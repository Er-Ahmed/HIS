package com.usa.his.ed.rules.request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import com.usa.his.ed.rules.response.PlanInfo;

import lombok.Data;


/**
 * 
 * @author AHMED
 * 
 * This is a Request class for MedicaidPlanData
 * 
 */


/**
 * <p>
 * Java class for anonymous complex type.
 * 
 * <p>
 * The following schema fragment specifies the expected content contained within
 * this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="employment-income" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *         &lt;element name="properties-cost" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *         &lt;element name="other-income" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = { "employmentIncome", "propertiesCost", "otherIncome", "planInfo" })
@Data
public class MedicaidPlanData {

	@XmlElement(name = "employment-income")
	protected double employmentIncome;
	@XmlElement(name = "properties-cost")
	protected double propertiesCost;
	@XmlElement(name = "other-income")
	protected double otherIncome;

	private PlanInfo planInfo;

	
}
