package com.usa.his.dc.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

/**
 * 
 * @author AHMED
 * 
 * This class is created for PlanSelected Model
 *
 */

@Data
@Entity
@Table(name="PLAN_SELECT_MASTER")
public class PlanSelectedEntity {

	/**
	 * This Field is used for CASE_NUMBER
	 */
	@Id
	@Column(name="CASE_NUMBER")
	private Integer caseNumber;
	
	/**
	 * This Field is used for PLAN_SELECTED
	 */
	@Column(name="PLAN_SELECTED")
	private String planSelected;
}
