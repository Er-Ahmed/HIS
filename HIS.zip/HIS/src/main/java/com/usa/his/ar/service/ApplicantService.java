package com.usa.his.ar.service;

import java.util.List;
import java.util.Map;

import org.springframework.data.domain.Page;

import com.usa.his.ar.entity.ApplicantEntity;
import com.usa.his.ar.model.ApplicantModel;

/**
 * 
 * @author AHMED
 * 
 * This interface is created for ApplicantServiceImpl
 *
 */
public interface ApplicantService {
	
	/**
	 * This Abstract method is used for Applicant Registration
	 * 
	 * @param appModel
	 * @return String
	 */
	public Map<String, String> applicantRegistration(ApplicantModel appModel) throws Exception;
	
	/**
	 * This Abstract method is used for ssn checking
	 * 
	 * @param ssn
	 * @return return
	 */
	public String checkForSSN(Long ssn);

	/**
	 * This Abstract method is used to retrive All Registered Applicants+
	 * 
	 * @return List<ApplicantModel>
	 */
	public Page<ApplicantEntity> retriveAllApplicant(Integer pageNo, String orderName, String orderType);
	
	/**
	 * This Abstract method is used to search List of Data
	 * 
	 * @param searchBy
	 * @param searchTxt
	 * @return List<ApplicantModel>
	 * 
	 */
	public List<ApplicantModel> searchingList(String searchBy, String searchTxt);
	
	/**
	 * This Abstract method is used to search Single Object Data
	 * 
	 * @param searchBy
	 * @param searchTxt
	 * @return ApplicantModel
	 * 
	 */
	public ApplicantModel searching(String searchBy, String searchTxt);
}
