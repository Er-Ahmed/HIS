package com.usa.his.admin.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.usa.his.admin.entity.AccEntity;
import com.usa.his.admin.model.AccModel;
import com.usa.his.admin.repository.AccountMasterRepository;
import com.usa.his.admin.repository.RoleMasterRepository;
import com.usa.his.util.JavaMailUtils;
import com.usa.his.util.PasswordUtils;

/**
 * 
 * @author AHMED
 * 
 * 
 *         This class is created for Account ServiceImpl - Implementation class
 *
 */
@Service
public class AccServiceImpl implements AccService {

	/**
	 * 
	 * This is used to Generate Log messages
	 * 
	 */
	private static final Logger LOGGER = LogManager.getLogger(AccServiceImpl.class);

	/**
	 * 
	 * This filed is used to Inject the AdminMasterRepository Object
	 * 
	 */
	@Autowired
	private AccountMasterRepository adminRepo;

	/**
	 *
	 * This filed is used to Inject the RoleMasterReposity Object
	 * 
	 */
	@Autowired
	private RoleMasterRepository roleRepo;

	/**
	 * 
	 * This filed is used to Inject the MailServiceImpl Object
	 * 
	 */
	@Autowired
	private JavaMailUtils mailUtils;

	/**
	 * 
	 * 
	 * This method is used for accRegistration
	 * 
	 * 
	 */

	@Override
	public Boolean accRegistration(AccModel accModel) throws Exception  {
		LOGGER.debug("*** AccServiceImpl : accRegistration method Started ***");
		/**
		 * Variable Declaration
		 */
		AccEntity accEntity = null;
		String encryptedPass = null;

		/**
		 * Create AccountEnntity Object
		 */
		accEntity = new AccEntity();

		/**
		 * convert accModel to accEntity
		 */
		BeanUtils.copyProperties(accModel, accEntity);

		/**
		 * Set trgSW to Y means account is ACTIVE
		 */
		accEntity.setActiveSW("Y");

		/**
		 * Password Encryption + Encoding Using AES Cipher Algorithm
		 */
		encryptedPass = PasswordUtils.encryptPassword(accModel.getPassword());

		/**
		 * Set Encrypted Password to accEntity
		 */
		accEntity.setPassword(encryptedPass);

		/**
		 * Save the Recored
		 */
		accEntity = adminRepo.save(accEntity);

		/**
		 * 
		 * Call sendEmail method to send the Mail
		 * 
		 */
		if (accEntity.getId() > 0) {
			mailUtils.sendEmail(accModel);
		}

		/**
		 * If Recored saved Successfully return TRUE else FALSE
		 */

		LOGGER.debug("*** AccServiceImpl :  accRegistration method Ended ***");
		LOGGER.info("*** AccServiceImpl :  accRegistration method executed Successfully ***");

		return (accEntity.getId() > 0 ? true : false);
	}

	/**
	 * 
	 * This method is used to return List of Registered Accounts
	 * 
	 */

	@Override
	public List<AccModel> getAllAccounts() {

		LOGGER.debug("*** AccServiceImpl :  getAllAccounts method Started ***");
		/**
		 * Variable Declaration
		 */
		List<AccEntity> accEntityList = null;

		/**
		 * get All Records
		 */
		accEntityList = adminRepo.findAll();

		/**
		 * Create Object for accModelList
		 */
		List<AccModel> accModelList = new ArrayList<AccModel>(accEntityList.size());

		/**
		 * Convert accEntityList to accModelList
		 */
		accEntityList.forEach(accEntity -> {
			AccModel accModel = new AccModel();
			BeanUtils.copyProperties(accEntity, accModel);
			accModelList.add(accModel);
		});

		LOGGER.debug("*** AccServiceImpl :  getAllAccounts method Ended ***");
		LOGGER.info("*** AccServiceImpl :  getAllAccounts method executed Successfully ***");

		return accModelList;
	}

	/**
	 * This method will return all accRoles
	 */
	@Override
	@Cacheable(value = "rolesCache")
	public List<String> getAccRolesList() {

		LOGGER.debug("*** AccServiceImpl :  getAccRolesList method Started ***");

		/**
		 * Get all Account Roles
		 */
		List<String> accRoleList = roleRepo.getAccRolesList();

		LOGGER.debug("*** AccServiceImpl :  getAccRolesList method Ended ***");
		LOGGER.info("*** AccServiceImpl :  getAccRolesList method executed Successfully ***");

		/**
		 * Return roleModelList to Controller
		 */
		return accRoleList;
	}

	@Override
	public String checkForEmail(String email) {

		LOGGER.debug("*** AccServiceImpl :  checkForEmail method Started ***");

		String emailId = adminRepo.findByEmail(email);

		LOGGER.debug("*** AccServiceImpl :  checkForEmail method Ended ***");
		LOGGER.info("*** AccServiceImpl :  checkForEmail method executed Successfully ***");

		return (emailId == null) ? "Unique" : "Duplicate";
	}

	@Override
	public String deActiveAccountById(Integer id) {

		LOGGER.debug("*** AccServiceImpl :  deActiveAccountById method Started ***");

		Integer result = adminRepo.deActivateUserById(id);

		LOGGER.debug("*** AccServiceImpl :  deActiveAccountById method Ended ***");
		LOGGER.info("*** AccServiceImpl :  deActiveAccountById method executed Successfully ***");

		if (result > 0) {

			return "Account De-Activation Successfull";
		} else {
			return "Account DeActivation Fail";
		}

	}

	@Override
	public String activeAccountById(Integer id) {

		LOGGER.debug("*** AccServiceImpl :  activeAccountById method Started ***");

		Integer result = adminRepo.activateUserById(id);

		LOGGER.debug("*** AccServiceImpl :  activeAccountById method Ended ***");
		LOGGER.info("*** AccServiceImpl :  activeAccountById method executed Successfully ***");

		if (result > 0) {

			return "Account Activation Success";
		} else {
			return "Account Activation Fail";
		}
	}
}
