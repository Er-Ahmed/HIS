package com.usa.his.admin.service;

import java.util.List;

import com.usa.his.admin.model.AccModel;

/**
 * 
 * @author AHMED
 * 
 * 
 *         This interface is created for AccServiceImpl
 *
 */
public interface AccService {

	/**
	 * This Abstract method is used to save the data
	 * 
	 * @param userModel
	 * @return Boolean
	 */
	public Boolean accRegistration(AccModel accModel) throws Exception;

	/**
	 * This method is used to get all Accounts
	 * 
	 * @return List<UserModel>
	 */
	public List<AccModel> getAllAccounts();

	/**
	 * This Abstract methods will return all AccountRoles
	 * 
	 * @return List<String>
	 */
	public List<String> getAccRolesList();

	/**
	 * This Abstract method is used to check weather input email is already present
	 * in DB
	 * 
	 * 
	 * @return String
	 */
	public String checkForEmail(String email);

	/**
	 * This Abstract method is used to DeActive the Account By Id
	 * 
	 * @param id
	 * @return String
	 */
	public String deActiveAccountById(Integer id);

	/**
	 * This Abstract method is used to Activate the Account By Id
	 * 
	 * @param id
	 * @return String
	 */
	public String activeAccountById(Integer id);

}
