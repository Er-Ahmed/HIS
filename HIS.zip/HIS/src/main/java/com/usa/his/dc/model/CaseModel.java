package com.usa.his.dc.model;

import java.util.Date;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import lombok.Data;

/**
 * 
 * @author AHMED
 * 
 * 
 *         This class is created for Create Case Model
 *
 */

@Data
public class CaseModel {

	/**
	 * This Field is used for CASE_NUMBER
	 */
	private Integer caseNumber;
	
	/**
	 * This Field is used for REG_NUMBER
	 */
	private Integer regNumber;

	/**
	 * This Field is used for FIRST_NAME
	 */
	private String firstName;

	/**
	 * This Field is used for LAST_NAME
	 */
	private String lastName;

	/**
	 * This Field is used for GENDER
	 */
	private String gender;
	
	/**
	 * This Field is used for DOB
	 */
	private String dob;

	/**
	 * This Field is used for EMAIL
	 */
	private String email;

	/**
	 * This Field is used for SSN
	 */
	private Long ssn;

	/**
	 * This Field is used for MOBILE_NUMBER
	 */
	private Long mobileNumber;

	
	/**
	 * This Field is used for CREATION_DATE
	 */
	private Date creationDate;

	/**
	 * This Field is used for UPDATION_DATE
	 */
	private Date updationDate;
}
