package com.his;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.usa.his.admin.model.AccModel;
import com.usa.his.admin.service.AccService;

/**
 * 
 * @author AHMED
 * 
 *         This class is used to Test the AccServiceImpl
 *
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class HisApplicationTests {

	/**
	 * This Property is used to Inject AccountServceImpl class Object
	 */
	@Autowired
	private AccService service;

	/**
	 * This method is used to check processAccountRegistration()
	 */
	@Ignore
	@Test
	public void processAccRegistration_Test() throws Exception {
		AccModel userModel = new AccModel();
		userModel.setFirstName("James");
		userModel.setLastName("Goslin");
		userModel.setDob("01/07/1989");
		userModel.setGender("Male");
		userModel.setEmail("John@gmail.com");
		userModel.setPassword("John@123");
		userModel.setSsn(987654321L);
		userModel.setMobileNumber(9876543210L);

		Boolean result = service.accRegistration(userModel);

		assertEquals(true, result);
	}

	/**
	 * This method is used to check getAccList()
	 */
	@Ignore
	@Test
	public void getAccList_Test() {
		assertNotNull(service.getAllAccounts());
	}

	/**
	 * This method is used to check checkForEmail() --- Unique
	 */
	@Ignore
	@Test
	public void checkForEmail_Unique_Test() {
		assertEquals("Unique", service.checkForEmail("er.ahmed@gmail.com"));
	}

	/**
	 * This method is used to check checkForEmail() --- Duplicate
	 */
	@Ignore
	@Test
	public void checkForEmail_Duplicate_Test() {
		assertEquals("Duplicate", service.checkForEmail("er.ahmedsk@gmail.com"));
	}

	@Test
	public void deActive_Account_Test() {
		assertEquals("Account De-Activation Successfull", service.deActiveAccountById(1));
	}

	@Test
	public void active_Account_Test() {
		assertEquals("Account Activation Success", service.activeAccountById(1));
	}
}
